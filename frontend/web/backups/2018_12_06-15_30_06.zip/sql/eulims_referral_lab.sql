-- MySQL dump 10.13  Distrib 5.7.16, for Win64 (x86_64)
--
-- Host: localhost    Database: eulims_referral_lab
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_agencydetails`
--

DROP TABLE IF EXISTS `tbl_agencydetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_agencydetails` (
  `agencydetails_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contacts` text NOT NULL,
  `short_name` varchar(15) NOT NULL,
  `lab_name` varchar(255) NOT NULL,
  `labtype_short` varchar(5) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`agencydetails_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_agencydetails`
--

LOCK TABLES `tbl_agencydetails` WRITE;
/*!40000 ALTER TABLE `tbl_agencydetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_agencydetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_analysis`
--

DROP TABLE IF EXISTS `tbl_analysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_analysis` (
  `analysis_id` int(11) NOT NULL AUTO_INCREMENT,
  `analysis_type_id` int(11) NOT NULL DEFAULT '1',
  `date_analysis` date NOT NULL,
  `agency_id` int(11) NOT NULL,
  `pstcanalysis_id` int(11) NOT NULL,
  `sample_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `methodreference_id` int(11) NOT NULL,
  `analysis_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cancelled` tinyint(1) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`analysis_id`),
  KEY `sample_id` (`sample_id`),
  KEY `test_id` (`test_id`),
  KEY `methodreference_id` (`methodreference_id`),
  CONSTRAINT `tbl_analysis_ibfk_2` FOREIGN KEY (`test_id`) REFERENCES `tbl_test_remove` (`test_id`),
  CONSTRAINT `tbl_analysis_ibfk_3` FOREIGN KEY (`sample_id`) REFERENCES `tbl_sample` (`sample_id`),
  CONSTRAINT `tbl_analysis_ibfk_4` FOREIGN KEY (`test_id`) REFERENCES `tbl_test` (`test_id`),
  CONSTRAINT `tbl_analysis_ibfk_5` FOREIGN KEY (`methodreference_id`) REFERENCES `tbl_methodreference` (`methodreference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_analysis`
--

LOCK TABLES `tbl_analysis` WRITE;
/*!40000 ALTER TABLE `tbl_analysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_analysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_attachment`
--

DROP TABLE IF EXISTS `tbl_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_attachment` (
  `attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(350) NOT NULL,
  `filetype` tinyint(2) NOT NULL COMMENT '1=OR, 2=Receipt, 3=Test Result',
  `referral_id` int(11) NOT NULL,
  `upload_date` datetime NOT NULL,
  `upload_by` int(11) NOT NULL,
  PRIMARY KEY (`attachment_id`),
  KEY `referral_id` (`referral_id`),
  CONSTRAINT `tbl_attachment_ibfk_1` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_attachment`
--

LOCK TABLES `tbl_attachment` WRITE;
/*!40000 ALTER TABLE `tbl_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bid`
--

DROP TABLE IF EXISTS `tbl_bid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bid` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `bidder_agency_id` int(11) NOT NULL,
  `sample_requirements` text NOT NULL,
  `bid_amount` decimal(10,2) NOT NULL,
  `remarks` varchar(200) NOT NULL,
  `estimated_due` date NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`bid_id`),
  KEY `referral_id` (`referral_id`),
  CONSTRAINT `tbl_bid_ibfk_1` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bid`
--

LOCK TABLES `tbl_bid` WRITE;
/*!40000 ALTER TABLE `tbl_bid` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_bid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_cancelledreferral`
--

DROP TABLE IF EXISTS `tbl_cancelledreferral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cancelledreferral` (
  `cancelledreferral_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `cancel_date` datetime NOT NULL,
  `agency_id` int(11) NOT NULL,
  `cancelled_by` int(11) NOT NULL,
  PRIMARY KEY (`cancelledreferral_id`),
  KEY `referral_id` (`referral_id`),
  CONSTRAINT `tbl_cancelledreferral_ibfk_1` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cancelledreferral`
--

LOCK TABLES `tbl_cancelledreferral` WRITE;
/*!40000 ALTER TABLE `tbl_cancelledreferral` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_cancelledreferral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_configlab`
--

DROP TABLE IF EXISTS `tbl_configlab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_configlab` (
  `configlab_id` int(11) NOT NULL AUTO_INCREMENT,
  `rstl_id` int(11) NOT NULL,
  `lab` varchar(25) CHARACTER SET latin1 NOT NULL DEFAULT '1,2,3',
  PRIMARY KEY (`configlab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_configlab`
--

LOCK TABLES `tbl_configlab` WRITE;
/*!40000 ALTER TABLE `tbl_configlab` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_configlab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_counter`
--

DROP TABLE IF EXISTS `tbl_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_counter` (
  `counter_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET latin1 NOT NULL,
  `number` int(11) NOT NULL,
  PRIMARY KEY (`counter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_counter`
--

LOCK TABLES `tbl_counter` WRITE;
/*!40000 ALTER TABLE `tbl_counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_courier`
--

DROP TABLE IF EXISTS `tbl_courier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_courier` (
  `courier_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`courier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_courier`
--

LOCK TABLES `tbl_courier` WRITE;
/*!40000 ALTER TABLE `tbl_courier` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_courier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_discount`
--

DROP TABLE IF EXISTS `tbl_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_discount` (
  `discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) CHARACTER SET latin1 NOT NULL,
  `rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_discount`
--

LOCK TABLES `tbl_discount` WRITE;
/*!40000 ALTER TABLE `tbl_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_fee`
--

DROP TABLE IF EXISTS `tbl_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_fee` (
  `fee_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `code` varchar(12) CHARACTER SET latin1 NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`fee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_fee`
--

LOCK TABLES `tbl_fee` WRITE;
/*!40000 ALTER TABLE `tbl_fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_formop`
--

DROP TABLE IF EXISTS `tbl_formop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_formop` (
  `formop_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `rev_num` varchar(20) NOT NULL,
  `print_format` int(11) NOT NULL,
  `rev_date` varchar(20) NOT NULL,
  `logo_left` varchar(200) NOT NULL,
  `logo_right` varchar(200) NOT NULL,
  PRIMARY KEY (`formop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_formop`
--

LOCK TABLES `tbl_formop` WRITE;
/*!40000 ALTER TABLE `tbl_formop` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_formop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_formrequest`
--

DROP TABLE IF EXISTS `tbl_formrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_formrequest` (
  `formrequest_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `number` varchar(20) NOT NULL,
  `rev_num` varchar(20) NOT NULL,
  `print_format` int(11) NOT NULL,
  `rev_date` varchar(20) NOT NULL,
  `logo_left` varchar(200) NOT NULL,
  `logo_right` varchar(200) NOT NULL,
  PRIMARY KEY (`formrequest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_formrequest`
--

LOCK TABLES `tbl_formrequest` WRITE;
/*!40000 ALTER TABLE `tbl_formrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_formrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_generatedrequest`
--

DROP TABLE IF EXISTS `tbl_generatedrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_generatedrequest` (
  `generatedrequest_id` int(11) NOT NULL AUTO_INCREMENT,
  `rstl_id` int(11) DEFAULT NULL,
  `request_id` int(11) DEFAULT NULL,
  `lab_id` tinyint(1) DEFAULT NULL,
  `year` int(11) NOT NULL,
  `number` int(1) NOT NULL,
  PRIMARY KEY (`generatedrequest_id`),
  KEY `request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_generatedrequest`
--

LOCK TABLES `tbl_generatedrequest` WRITE;
/*!40000 ALTER TABLE `tbl_generatedrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_generatedrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_initializecode`
--

DROP TABLE IF EXISTS `tbl_initializecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_initializecode` (
  `initializecode_id` int(11) NOT NULL AUTO_INCREMENT,
  `rstl_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `code_type` int(11) NOT NULL,
  `start_code` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`initializecode_id`),
  KEY `lab_id` (`lab_id`),
  CONSTRAINT `tbl_initializecode_ibfk_1` FOREIGN KEY (`lab_id`) REFERENCES `tbl_lab` (`lab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_initializecode`
--

LOCK TABLES `tbl_initializecode` WRITE;
/*!40000 ALTER TABLE `tbl_initializecode` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_initializecode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_lab`
--

DROP TABLE IF EXISTS `tbl_lab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_lab` (
  `lab_id` int(11) NOT NULL AUTO_INCREMENT,
  `labname` varchar(50) CHARACTER SET latin1 NOT NULL,
  `labcode` varchar(10) CHARACTER SET latin1 NOT NULL,
  `labcount` int(11) NOT NULL,
  `nextrequestcode` varchar(50) CHARACTER SET latin1 NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`lab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_lab`
--

LOCK TABLES `tbl_lab` WRITE;
/*!40000 ALTER TABLE `tbl_lab` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_lab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_labsampletype`
--

DROP TABLE IF EXISTS `tbl_labsampletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_labsampletype` (
  `labsampletype_id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_id` int(11) NOT NULL,
  `sampletype_id` int(11) NOT NULL,
  `date_added` date NOT NULL,
  `added_by` varchar(10) NOT NULL,
  PRIMARY KEY (`labsampletype_id`),
  UNIQUE KEY `lab_id` (`lab_id`,`sampletype_id`),
  KEY `sampletype_id` (`sampletype_id`),
  CONSTRAINT `tbl_labsampletype_ibfk_1` FOREIGN KEY (`sampletype_id`) REFERENCES `tbl_sampletype` (`sampletype_id`),
  CONSTRAINT `tbl_labsampletype_ibfk_2` FOREIGN KEY (`lab_id`) REFERENCES `tbl_lab` (`lab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_labsampletype`
--

LOCK TABLES `tbl_labsampletype` WRITE;
/*!40000 ALTER TABLE `tbl_labsampletype` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_labsampletype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_methodreference`
--

DROP TABLE IF EXISTS `tbl_methodreference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_methodreference` (
  `methodreference_id` int(11) NOT NULL AUTO_INCREMENT,
  `method` varchar(200) NOT NULL,
  `reference` varchar(200) NOT NULL,
  `fee` float(11,2) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`methodreference_id`),
  UNIQUE KEY `method` (`method`,`reference`,`fee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_methodreference`
--

LOCK TABLES `tbl_methodreference` WRITE;
/*!40000 ALTER TABLE `tbl_methodreference` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_methodreference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_modeofrelease`
--

DROP TABLE IF EXISTS `tbl_modeofrelease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_modeofrelease` (
  `modeofrelease_id` int(11) NOT NULL,
  `mode` varchar(25) CHARACTER SET latin1 NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`modeofrelease_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_modeofrelease`
--

LOCK TABLES `tbl_modeofrelease` WRITE;
/*!40000 ALTER TABLE `tbl_modeofrelease` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_modeofrelease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_nominatedemail`
--

DROP TABLE IF EXISTS `tbl_nominatedemail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_nominatedemail` (
  `nominatedemail_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `status` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`nominatedemail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_nominatedemail`
--

LOCK TABLES `tbl_nominatedemail` WRITE;
/*!40000 ALTER TABLE `tbl_nominatedemail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_nominatedemail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_notification`
--

DROP TABLE IF EXISTS `tbl_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_notification` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `notificationtype_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_name` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `viewed` tinyint(2) NOT NULL,
  `notification_date` datetime NOT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_notification`
--

LOCK TABLES `tbl_notification` WRITE;
/*!40000 ALTER TABLE `tbl_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_packagelist`
--

DROP TABLE IF EXISTS `tbl_packagelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_packagelist` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_id` int(11) NOT NULL,
  `sampletype_id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `test_method` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`package_id`),
  KEY `testcategory_id` (`lab_id`),
  KEY `sampletype_id` (`sampletype_id`),
  CONSTRAINT `tbl_packagelist_ibfk_1` FOREIGN KEY (`lab_id`) REFERENCES `tbl_testcategory` (`testcategory_id`),
  CONSTRAINT `tbl_packagelist_ibfk_2` FOREIGN KEY (`sampletype_id`) REFERENCES `tbl_sample` (`sample_id`),
  CONSTRAINT `tbl_packagelist_ibfk_3` FOREIGN KEY (`lab_id`) REFERENCES `tbl_lab` (`lab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_packagelist`
--

LOCK TABLES `tbl_packagelist` WRITE;
/*!40000 ALTER TABLE `tbl_packagelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_packagelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_packageoffer`
--

DROP TABLE IF EXISTS `tbl_packageoffer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_packageoffer` (
  `packageoffer_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `packagelist_id` int(11) NOT NULL,
  `offered_date` datetime NOT NULL,
  PRIMARY KEY (`packageoffer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_packageoffer`
--

LOCK TABLES `tbl_packageoffer` WRITE;
/*!40000 ALTER TABLE `tbl_packageoffer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_packageoffer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_paymenttype`
--

DROP TABLE IF EXISTS `tbl_paymenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_paymenttype` (
  `payment_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`payment_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_paymenttype`
--

LOCK TABLES `tbl_paymenttype` WRITE;
/*!40000 ALTER TABLE `tbl_paymenttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_paymenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pstc`
--

DROP TABLE IF EXISTS `tbl_pstc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pstc` (
  `id` int(11) NOT NULL,
  `agency_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pstc`
--

LOCK TABLES `tbl_pstc` WRITE;
/*!40000 ALTER TABLE `tbl_pstc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pstc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pstcactions`
--

DROP TABLE IF EXISTS `tbl_pstcactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pstcactions` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `pstc_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `actionDetail` varchar(25) NOT NULL,
  `actionDate` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pstcactions`
--

LOCK TABLES `tbl_pstcactions` WRITE;
/*!40000 ALTER TABLE `tbl_pstcactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pstcactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pstcanalysis`
--

DROP TABLE IF EXISTS `tbl_pstcanalysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pstcanalysis` (
  `id` int(11) NOT NULL,
  `rstl_id` int(11) NOT NULL,
  `pstcanalysis_id` int(11) NOT NULL,
  `requestId` varchar(50) NOT NULL,
  `sample_id` int(11) NOT NULL,
  `sampleCode` varchar(20) NOT NULL,
  `testName` varchar(200) NOT NULL,
  `method` varchar(150) NOT NULL,
  `references` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `fee` float NOT NULL,
  `testId` int(11) NOT NULL,
  `analysisMonth` int(11) NOT NULL,
  `analysisYear` int(11) NOT NULL,
  `package` int(11) NOT NULL,
  `cancelled` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `taggingId` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pstcanalysis`
--

LOCK TABLES `tbl_pstcanalysis` WRITE;
/*!40000 ALTER TABLE `tbl_pstcanalysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pstcanalysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pstcrequest`
--

DROP TABLE IF EXISTS `tbl_pstcrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pstcrequest` (
  `id` int(11) NOT NULL,
  `pstc_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `submittedBy` varchar(25) NOT NULL,
  `status_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `requestDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pstcrequest`
--

LOCK TABLES `tbl_pstcrequest` WRITE;
/*!40000 ALTER TABLE `tbl_pstcrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pstcrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pstcsample`
--

DROP TABLE IF EXISTS `tbl_pstcsample`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pstcsample` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `sampleType_id` int(11) NOT NULL,
  `sampleName` varchar(40) NOT NULL,
  `description` text NOT NULL,
  `processed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pstcsample`
--

LOCK TABLES `tbl_pstcsample` WRITE;
/*!40000 ALTER TABLE `tbl_pstcsample` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pstcsample` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_purpose`
--

DROP TABLE IF EXISTS `tbl_purpose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_purpose` (
  `purpose_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`purpose_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_purpose`
--

LOCK TABLES `tbl_purpose` WRITE;
/*!40000 ALTER TABLE `tbl_purpose` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_purpose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_referral`
--

DROP TABLE IF EXISTS `tbl_referral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referral` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_code` varchar(50) NOT NULL,
  `referral_date` date NOT NULL,
  `referral_time` varchar(10) NOT NULL,
  `receiving_agency_id` int(11) NOT NULL,
  `testing_agency_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `sample_received_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_type_id` int(11) NOT NULL DEFAULT '0',
  `modeofrelease_id` int(11) NOT NULL,
  `purpose_id` int(11) NOT NULL,
  `discount_id` int(11) NOT NULL DEFAULT '0',
  `discount_amt` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `report_due` date NOT NULL,
  `conforme` varchar(50) NOT NULL,
  `received_by` int(11) NOT NULL,
  `bid` tinyint(1) NOT NULL DEFAULT '0',
  `cancelled` tinyint(1) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`referral_id`),
  KEY `payment_type_id` (`payment_type_id`),
  KEY `modeofrelease_id` (`modeofrelease_id`),
  KEY `lab_id` (`lab_id`),
  KEY `discount_id` (`discount_id`),
  KEY `purpose_id` (`purpose_id`),
  CONSTRAINT `tbl_referral_ibfk_1` FOREIGN KEY (`payment_type_id`) REFERENCES `tbl_paymenttype` (`payment_type_id`),
  CONSTRAINT `tbl_referral_ibfk_2` FOREIGN KEY (`modeofrelease_id`) REFERENCES `tbl_modeofrelease` (`modeofrelease_id`),
  CONSTRAINT `tbl_referral_ibfk_3` FOREIGN KEY (`lab_id`) REFERENCES `tbl_lab` (`lab_id`),
  CONSTRAINT `tbl_referral_ibfk_4` FOREIGN KEY (`discount_id`) REFERENCES `tbl_discount` (`discount_id`),
  CONSTRAINT `tbl_referral_ibfk_5` FOREIGN KEY (`purpose_id`) REFERENCES `tbl_purpose` (`purpose_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_referral`
--

LOCK TABLES `tbl_referral` WRITE;
/*!40000 ALTER TABLE `tbl_referral` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_referral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_referralcode`
--

DROP TABLE IF EXISTS `tbl_referralcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referralcode` (
  `referralcode_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `referral_code` varchar(50) NOT NULL,
  `agency_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`referralcode_id`),
  KEY `lab_id` (`lab_id`),
  CONSTRAINT `tbl_referralcode_ibfk_1` FOREIGN KEY (`lab_id`) REFERENCES `tbl_lab` (`lab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_referralcode`
--

LOCK TABLES `tbl_referralcode` WRITE;
/*!40000 ALTER TABLE `tbl_referralcode` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_referralcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_referralstatus`
--

DROP TABLE IF EXISTS `tbl_referralstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referralstatus` (
  `referralstatus_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(75) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`referralstatus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_referralstatus`
--

LOCK TABLES `tbl_referralstatus` WRITE;
/*!40000 ALTER TABLE `tbl_referralstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_referralstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_referraltrackreceiving`
--

DROP TABLE IF EXISTS `tbl_referraltrackreceiving`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referraltrackreceiving` (
  `referraltrackreceiving_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `receiving_agency_id` int(11) NOT NULL,
  `testing_agency_id` int(11) NOT NULL,
  `sample_received_date` date NOT NULL,
  `courier_id` int(11) NOT NULL,
  `shipping_date` date NOT NULL,
  `cal_specimen_received_date` date DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`referraltrackreceiving_id`),
  KEY `referral_id` (`referral_id`),
  KEY `courier_id` (`courier_id`),
  CONSTRAINT `tbl_referraltrackreceiving_ibfk_1` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`),
  CONSTRAINT `tbl_referraltrackreceiving_ibfk_2` FOREIGN KEY (`courier_id`) REFERENCES `tbl_courier` (`courier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_referraltrackreceiving`
--

LOCK TABLES `tbl_referraltrackreceiving` WRITE;
/*!40000 ALTER TABLE `tbl_referraltrackreceiving` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_referraltrackreceiving` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_referraltracktesting`
--

DROP TABLE IF EXISTS `tbl_referraltracktesting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referraltracktesting` (
  `referraltracktesting_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `testing_agency_id` int(11) NOT NULL,
  `receiving_agency_id` int(11) NOT NULL,
  `date_received_courier` date NOT NULL,
  `analysis_started` date DEFAULT NULL,
  `analysis_completed` date DEFAULT NULL,
  `cal_specimen_send_date` date DEFAULT NULL,
  `courier_id` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`referraltracktesting_id`),
  KEY `referral_id` (`referral_id`),
  KEY `courier_id` (`courier_id`),
  CONSTRAINT `tbl_referraltracktesting_ibfk_1` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`),
  CONSTRAINT `tbl_referraltracktesting_ibfk_2` FOREIGN KEY (`courier_id`) REFERENCES `tbl_courier` (`courier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_referraltracktesting`
--

LOCK TABLES `tbl_referraltracktesting` WRITE;
/*!40000 ALTER TABLE `tbl_referraltracktesting` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_referraltracktesting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rstlpackage`
--

DROP TABLE IF EXISTS `tbl_rstlpackage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rstlpackage` (
  `id` int(11) NOT NULL,
  `localulims_id` int(11) DEFAULT NULL,
  `rstl_id` int(11) NOT NULL,
  `testcategory_id` int(11) NOT NULL,
  `sampletype_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `rate` float(11,2) NOT NULL,
  `tests` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rstlpackage`
--

LOCK TABLES `tbl_rstlpackage` WRITE;
/*!40000 ALTER TABLE `tbl_rstlpackage` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_rstlpackage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rstlsampletype`
--

DROP TABLE IF EXISTS `tbl_rstlsampletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rstlsampletype` (
  `id` int(11) NOT NULL,
  `rstl_id` int(11) NOT NULL,
  `localulims_id` int(11) NOT NULL,
  `sampleType` varchar(75) NOT NULL,
  `testCategoryId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rstlsampletype`
--

LOCK TABLES `tbl_rstlsampletype` WRITE;
/*!40000 ALTER TABLE `tbl_rstlsampletype` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_rstlsampletype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rstltest`
--

DROP TABLE IF EXISTS `tbl_rstltest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rstltest` (
  `id` int(11) NOT NULL,
  `localulims_id` int(11) NOT NULL,
  `rstl_id` int(11) NOT NULL,
  `testName` varchar(200) NOT NULL,
  `method` varchar(150) NOT NULL,
  `references` varchar(100) NOT NULL,
  `fee` float NOT NULL,
  `duration` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `sampleType` int(11) NOT NULL,
  `labId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rstltest`
--

LOCK TABLES `tbl_rstltest` WRITE;
/*!40000 ALTER TABLE `tbl_rstltest` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_rstltest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rstltestcategory`
--

DROP TABLE IF EXISTS `tbl_rstltestcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rstltestcategory` (
  `id` int(11) NOT NULL,
  `rstl_id` int(11) NOT NULL,
  `localulims_id` int(11) NOT NULL,
  `categoryName` varchar(200) NOT NULL,
  `labId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rstltestcategory`
--

LOCK TABLES `tbl_rstltestcategory` WRITE;
/*!40000 ALTER TABLE `tbl_rstltestcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_rstltestcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sample`
--

DROP TABLE IF EXISTS `tbl_sample`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sample` (
  `sample_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `receiving_agency_id` int(11) NOT NULL,
  `pstcsample_id` int(11) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `package_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sample_type_id` int(11) NOT NULL,
  `sample_code` varchar(20) CHARACTER SET latin1 NOT NULL,
  `samplename` varchar(150) CHARACTER SET latin1 NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL,
  `sampling_date` date NOT NULL,
  `remarks` varchar(150) CHARACTER SET latin1 NOT NULL,
  `sample_month` int(11) NOT NULL,
  `sample_year` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`sample_id`),
  KEY `sample_type_id` (`sample_type_id`),
  KEY `request_id` (`referral_id`),
  KEY `package_id` (`package_id`),
  CONSTRAINT `tbl_sample_ibfk_1` FOREIGN KEY (`sample_type_id`) REFERENCES `tbl_sampletype` (`sampletype_id`),
  CONSTRAINT `tbl_sample_ibfk_3` FOREIGN KEY (`package_id`) REFERENCES `tbl_packagelist` (`package_id`),
  CONSTRAINT `tbl_sample_ibfk_4` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`),
  CONSTRAINT `tbl_sample_ibfk_5` FOREIGN KEY (`package_id`) REFERENCES `tbl_packagelist` (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sample`
--

LOCK TABLES `tbl_sample` WRITE;
/*!40000 ALTER TABLE `tbl_sample` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_sample` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sampletemplate`
--

DROP TABLE IF EXISTS `tbl_sampletemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sampletemplate` (
  `sampletemplate_id` int(11) NOT NULL AUTO_INCREMENT,
  `samplename` varchar(100) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`sampletemplate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sampletemplate`
--

LOCK TABLES `tbl_sampletemplate` WRITE;
/*!40000 ALTER TABLE `tbl_sampletemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_sampletemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sampletype`
--

DROP TABLE IF EXISTS `tbl_sampletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sampletype` (
  `sampletype_id` int(11) NOT NULL AUTO_INCREMENT,
  `sample_type` varchar(75) CHARACTER SET latin1 NOT NULL,
  `test_category_id` int(11) NOT NULL,
  PRIMARY KEY (`sampletype_id`),
  KEY `test_category_id` (`test_category_id`),
  CONSTRAINT `tbl_sampletype_ibfk_1` FOREIGN KEY (`test_category_id`) REFERENCES `tbl_testcategory` (`testcategory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sampletype`
--

LOCK TABLES `tbl_sampletype` WRITE;
/*!40000 ALTER TABLE `tbl_sampletype` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_sampletype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sampletypetestname`
--

DROP TABLE IF EXISTS `tbl_sampletypetestname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sampletypetestname` (
  `sampletypetestname_id` int(11) NOT NULL AUTO_INCREMENT,
  `sampletype_id` int(11) NOT NULL,
  `testname_id` int(11) NOT NULL,
  `added_by` varchar(10) NOT NULL,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`sampletypetestname_id`),
  UNIQUE KEY `sampletype_id` (`sampletype_id`,`testname_id`),
  KEY `testname_id` (`testname_id`),
  CONSTRAINT `tbl_sampletypetestname_ibfk_1` FOREIGN KEY (`sampletype_id`) REFERENCES `tbl_sampletype` (`sampletype_id`),
  CONSTRAINT `tbl_sampletypetestname_ibfk_2` FOREIGN KEY (`testname_id`) REFERENCES `tbl_test` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sampletypetestname`
--

LOCK TABLES `tbl_sampletypetestname` WRITE;
/*!40000 ALTER TABLE `tbl_sampletypetestname` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_sampletypetestname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_service`
--

DROP TABLE IF EXISTS `tbl_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_service` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `method_ref_id` int(11) NOT NULL,
  `offered_date` int(11) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_service`
--

LOCK TABLES `tbl_service` WRITE;
/*!40000 ALTER TABLE `tbl_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_status`
--

DROP TABLE IF EXISTS `tbl_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_status`
--

LOCK TABLES `tbl_status` WRITE;
/*!40000 ALTER TABLE `tbl_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_statuslogs`
--

DROP TABLE IF EXISTS `tbl_statuslogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_statuslogs` (
  `statuslogs_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_id` int(11) NOT NULL,
  `referralstatus_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `remarks` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`statuslogs_id`),
  KEY `referral_id` (`referral_id`),
  KEY `referralstatus_id` (`referralstatus_id`),
  CONSTRAINT `tbl_statuslogs_ibfk_1` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`),
  CONSTRAINT `tbl_statuslogs_ibfk_2` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`),
  CONSTRAINT `tbl_statuslogs_ibfk_3` FOREIGN KEY (`referral_id`) REFERENCES `tbl_referral` (`referral_id`),
  CONSTRAINT `tbl_statuslogs_ibfk_4` FOREIGN KEY (`referralstatus_id`) REFERENCES `tbl_referralstatus` (`referralstatus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_statuslogs`
--

LOCK TABLES `tbl_statuslogs` WRITE;
/*!40000 ALTER TABLE `tbl_statuslogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_statuslogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_test`
--

DROP TABLE IF EXISTS `tbl_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_test` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_name` varchar(200) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_test`
--

LOCK TABLES `tbl_test` WRITE;
/*!40000 ALTER TABLE `tbl_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_test_method`
--

DROP TABLE IF EXISTS `tbl_test_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_test_method` (
  `test_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `methodreference_id` int(11) NOT NULL,
  `added_by` varchar(50) NOT NULL,
  `create_time` date NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`test_method_id`),
  KEY `methodreference_id` (`methodreference_id`),
  KEY `test_id` (`test_id`),
  CONSTRAINT `tbl_test_method_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tbl_test` (`test_id`),
  CONSTRAINT `tbl_test_method_ibfk_2` FOREIGN KEY (`methodreference_id`) REFERENCES `tbl_methodreference` (`methodreference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_test_method`
--

LOCK TABLES `tbl_test_method` WRITE;
/*!40000 ALTER TABLE `tbl_test_method` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_test_method` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-06 15:30:06
