-- MySQL dump 10.13  Distrib 5.7.16, for Win64 (x86_64)
--
-- Host: localhost    Database: eulims
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agency`
--

DROP TABLE IF EXISTS `agency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `country` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `name` varchar(256) NOT NULL,
  `code` varchar(10) NOT NULL,
  `description` text NOT NULL,
  `website` varchar(256) NOT NULL,
  `contact` text NOT NULL,
  `address` text NOT NULL,
  `geo_location` varchar(256) NOT NULL,
  `activated` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agency`
--

LOCK TABLES `agency` WRITE;
/*!40000 ALTER TABLE `agency` DISABLE KEYS */;
INSERT INTO `agency` (`id`, `region_id`, `country`, `region`, `province`, `city`, `name`, `code`, `description`, `website`, `contact`, `address`, `geo_location`, `activated`) VALUES (1,3,'Philippines','Region 1','La Union','San Fernando City','DOST-I','R1','','http://region1.dost.gov.ph/','','','16.607972, 120.315835',0),(2,4,'Philippines','Region 2','Cagayan','Tuguegarao City','DOST-II','R2','','http://region2.dost.gov.ph/','','','17.652242, 121.752502',0),(3,5,'Philippines','Region 3','Pampanga','San Fernando City','DOST-III','R3','','http://region3.dost.gov.ph/','','','15.066352, 120.657300',0),(4,6,'Philippines','Region 4A','Laguna','Los Baños','DOST-CALABARZON-L1','R4AL1','','http://region4a.dost.gov.ph/','RSTL : (049) 536-4390\nRML : (049) 536-8091','','14.172264, 121.223556',0),(5,6,'Philippines','Region 4A','Laguna','Los Baños','DOST-CALABARZON-L2','R4AL2','','http://region4a.dost.gov.ph/','(046) 419-2533','','14.278183, 120.868458',0),(6,7,'Philippines','Region 4B','Palawan','Puerto Princesa City','DOST-MIMAROPA','R4B','','http://region4b.dost.gov.ph/','','','9.784145, 118.734071',0),(7,8,'Philippines','Region 5','Albay','Legazpi City','DOST-V','R5','','http://region5.dost.gov.ph/','','','13.167125, 123.751951',0),(8,9,'Philippines','Region 6','Iloilo','Iloilo City','DOST-VI','R6','','http://region6.dost.gov.ph/','','','10.711773, 122.563898',0),(9,10,'Philippines','Region 7','Cebu','Cebu City','DOST-VII','R7','','http://ro7.dost.gov.ph/','','','10.326021, 123.896707',0),(10,11,'Philippines','Region 8','Leyte','Palo','DOST-VIII','R8','','http://region8.dost.gov.ph/','','','11.179108, 125.003762',0),(11,12,'Philippines','Region 9','Zamboanga del Sur','Zamboanga City','DOST-IX','R9','','http://region9.dost.gov.ph/','','','6.9031523, 122.0794235',0),(12,13,'Philippines','Region 10','Misamis Oriental','Cagayan de Oro City','DOST-X','R10','','http://region10.dost.gov.ph/','','','8.482154, 124.627571',0),(13,14,'Philippines','Region 11','Davao del Sur','Davao City','DOST-XI','R11','','http://region11.dost.gov.ph/','','','7.100831, 125.619313',0),(14,15,'Philippines','Region 12','Maguindanao','Cotabato City','DOST-XII-L1','R12L1','','http://region12.dost.gov.ph/','','','7.195893, 124.245030',0),(15,15,'Philippines','Region 12','South Cotabato','General Santos City','DOST-XII-L2','R12L2','','http://region12.dost.gov.ph/','','','7.195893, 124.245030',0),(16,2,'Philippines','CAR','Benguet','La Trinidad','DOST-CAR','CAR','','http://car.dost.gov.ph/','','','16.461068, 120.588391',0),(17,16,'Philippines','Region 13','Agusan del Norte','Butuan City','DOST-CARAGA','R13','','http://caraga.dost.gov.ph/','','','8.949169, 125.531068',0),(18,17,'Philippines','ARMM','Maguindanao','Cotabato City','DOST-ARMM','ARMM','','http://www.armm.dost.gov.ph/','','','7.1977899, 124.2461288',0),(19,1,'Philippines','NCR','Southern Manila District','Taguig City','DOST-FNRI','FNRI','','http://www.fnri.dost.gov.ph/','','','14.489892, 121.053114',0),(20,6,'Philippines','Region 4A','Laguna','Los Baños','DOST-FPRDI','FPRDI','','http://www.fprdi.dost.gov.ph/','','','14.156966, 121.235461',0),(21,1,'Philippines','NCR','Southern Manila District','Taguig City','DOST-ITDI','ITDI','','http://www.itdi.dost.gov.ph/','','','14.489730, 121.050719',0),(22,1,'Philippines','NCR','Southern Manila District','Taguig City','DOST-MIRDC','MIRDC','','http://www.mirdc.dost.gov.ph/','','','14.486842, 121.049609',0),(23,1,'Philippines','NCR','Southern Manila District','Taguig City','DOST-PTRI','PTRI','','http://www.ptri.dost.gov.ph/','','','14.487292, 121.047867',0),(24,1,'Philippines','NCR','Eastern Manila District','Quezon City','DOST-PNRI','PNRI','','http://www.pnri.dost.gov.ph/','','','14.661146, 121.055715',0),(25,6,'Philippines','Region 4A','Batangas','Batangas City','DOST-CALABARZON-L3','R4AL3','','http://region4a.dost.gov.ph/','(043) 425-4041','','13.7721064, 121.0611725',0),(26,6,'Philippines','Region 4A','Cavite','Trece Matires City','DOST-CALABARZON-L4','R4AL4','','','','','',0),(27,21,'Philippines','','Southern Manila District','Taguig City','DOST-ADMATEL','ADMATEL','','','','','14.4906516, 121.0529491',0),(101,1,'Philippines','NCR','Southern Manila District','Muntinlupa City','Food and Drug Administration','FDA','','http://www.fda.gov.ph/','','','14.412591, 121.042491',0),(102,1,'Philippines','NCR','Eastern Manila District','Quezon City','Department of Health – National Reference Laboratory','NRL','','http://www.nrleamcdoh.org/\r\n','','','14.641784, 121.047608',0),(103,1,'Philippines','NCR','Eastern Manila District','Quezon City','Fertilizer and Pesticide Authority','FPA','','http://fpa.da.gov.ph/','','','14.656744, 121.046948',0),(104,1,'Philippines','NCR','Southern Manila District','Makati City','SGS Philippines','SGS','','http://www.sgs.ph/\r\n','+63 (2) 784 9400','','14.547376, 121.015105',0),(105,1,'Philippines','NCR','Eastern Manila District','Quezon City','F.A.S.T. Laboratories (The First Analytical Services and Technical Cooperative) - Cubao Branch','FAST','','http://www.fastlaboratories.com.ph/\r\n','(02) 913-0240 to 41 (02) 912-6319','','14.623046, 121.062386',0),(106,1,'Philippines','NCR','Eastern Manila District','Quezon City','Philippine Institute of Pure and Applied Chemistry','PIPAC','','http://www.pipac.com.ph/','(02) 4266072 / (02) 4266001 local 4856, 4857','','14.638871, 121.076784\r\n',0),(107,1,'Philippines','NCR','Capital District','Manila','UP Manila – National Institutes of Health','NIH','','http://nih.upm.edu.ph/','(02) 526 4349 / (02) 526 4266','','14.575858, 120.987174',0),(108,1,'Philippines','','','','Bureau of Product Standards','BPS','','\r\nhttp://www.bps.dti.gov.ph/','(02) 890 5226\r\n','','14.562013, 121.026942',0),(109,1,'Philippines','','','','Philippine Accreditation Bureau\r\n','PAB','','\r\n','','','14.561937, 121.026962',0),(110,1,'Philippines','','','','Mines and Geosciences Bureau','MGB','','http://mgb.gov.ph/\r\n','','','7.069921, 125.618862',0),(111,1,'Philippines','NCR','Eastern Manila District','Mandaluyong City','Sentro sa Pagsusuri, Pagsasanay at Pangangasiwang Pang-Agham at Teknolohiyang Corporation','SENTROTEK','','http://www.sentrotek.com/','(02) 721-6500 / (02) 721-9699','','14.589715, 121.041646',0),(112,1,'Philippines','Region 4A','Batangas','Lipa City','Optimal Laboratories Inc.','OPTIMAL','','http://optimallabinc.com/','(043) 756-1292 / (02) 806-2863','','13.950488, 121.157258',0),(113,1,'Philippines','Region 4A','Cavite','Dasmariñas City','Jefcor Laboratories Inc.','JEFCOR','','http://jefcorlabs.com/','(046) 402-0765 / (046) 402-1318','','14.285475, 120.93755',0),(114,1,'Philippines','NCR','Southern Manila District','Makati City','Intertek Testing Services, Phils, Inc','INTERTEK','','http://www.intertek.com/','(02) 819-5841 local 619','','14.5332617, 121.0228318',0),(115,1,'Philippines','NCR','Eastern Manila District','Quezon City','Qualibet Testing Services Corporation','QUALIBET','','http://qualibetlab.com/','(02) 374-8003','121 Dangay Street, Quezon City, 1100 Metro Manila, Philippines','14.6555173, 121.0257825',0),(116,10,'Philippines','Region 7','Cebu','Cebu City','GCH Center For Food Safety and Qaulity, Inc.','GCH','','https://www.facebook.com/gchcenterfoodsafetylab/','(02) 731-7714','Unit 6 GCH Building, Tres Borces Street, Mabolo, Cebu City, Philippines','10.3178494, 123.9153889',0),(117,6,'Philippines','Region 4A','Laguna','Biñan City','OSTREA Mineral Laboratories, Inc.','OSTREA','','http://ostrealabs.com.ph','(02) 889-9058 Loc 308','Barangay Road, Bo. Mamplasan, Biñan, Laguna, Philippines','14.293428, 121.082397',0);
/*!40000 ALTER TABLE `agency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_api_settings`
--

DROP TABLE IF EXISTS `tbl_api_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_api_settings` (
  `api_settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `rstl_id` int(11) NOT NULL,
  `api_url` varchar(100) NOT NULL,
  `get_token_url` varchar(100) NOT NULL,
  `request_token` varchar(100) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`api_settings_id`),
  UNIQUE KEY `rstl_id` (`rstl_id`),
  CONSTRAINT `tbl_api_settings_ibfk_1` FOREIGN KEY (`rstl_id`) REFERENCES `tbl_rstl` (`rstl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_api_settings`
--

LOCK TABLES `tbl_api_settings` WRITE;
/*!40000 ALTER TABLE `tbl_api_settings` DISABLE KEYS */;
INSERT INTO `tbl_api_settings` (`api_settings_id`, `rstl_id`, `api_url`, `get_token_url`, `request_token`, `created_at`, `updated_at`) VALUES (1,11,'https://api3.onelab.ph','https://api3.onelab.ph/access/get-access-token','ef3efa12025da3e86c267e2f2ee52ff3574e5225',1536287931,1536300369),(3,1,'https://api3.onelab.ph','https://api3.onelab.ph/access/get-access-token','5ba4bf89bff1603be68fdbe482436882d0f3bb2d',1536307837,1536307968);
/*!40000 ALTER TABLE `tbl_api_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_auth_assignment`
--

DROP TABLE IF EXISTS `tbl_auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `auth_assignment_user_id_idx` (`user_id`),
  CONSTRAINT `tbl_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `tbl_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_auth_assignment`
--

LOCK TABLES `tbl_auth_assignment` WRITE;
/*!40000 ALTER TABLE `tbl_auth_assignment` DISABLE KEYS */;
INSERT INTO `tbl_auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES ('access-his-profile','33',1533100405),('access-his-profile','5',1514427468),('Accountant','27',1532584538),('Accountant','33',1533100320),('Accountant','34',1533100551),('Analyst','26',1532584526),('Analyst','28',1532584559),('Analyst','30',1532655058),('basic-role','18',1517984550),('Cashier','27',1532584535),('Cashier Manager','24',1532402211),('CRO','23',1532322134),('CRO','24',1532403428),('CRO','25',1532584406),('CRO','28',1532584562),('CRO','29',1532655046),('lab-manager','18',1524128628),('lab-manager','2',1526971112),('lab-manager','28',1532584552),('lab-manager','32',1532655068),('lab-manager','5',1516858459),('super-administrator','1',NULL),('super-administrator','13',1523952934),('super-administrator','20',1532315638);
/*!40000 ALTER TABLE `tbl_auth_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_auth_item`
--

DROP TABLE IF EXISTS `tbl_auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `tbl_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `tbl_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_auth_item`
--

LOCK TABLES `tbl_auth_item` WRITE;
/*!40000 ALTER TABLE `tbl_auth_item` DISABLE KEYS */;
INSERT INTO `tbl_auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES ('/*',2,NULL,NULL,NULL,1513914178,1513914178),('/accounting/*',2,NULL,NULL,NULL,1515371555,1515371555),('/admin/*',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/assignment/*',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/assignment/assign',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/assignment/index',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/assignment/revoke',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/assignment/view',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/default/*',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/default/index',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/menu/*',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/menu/create',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/menu/delete',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/menu/index',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/menu/update',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/menu/view',2,NULL,NULL,NULL,1512924430,1512924430),('/admin/permission/*',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/permission/assign',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/permission/create',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/permission/delete',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/permission/index',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/permission/remove',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/permission/update',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/permission/view',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/*',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/assign',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/create',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/delete',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/index',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/remove',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/update',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/role/view',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/route/*',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/route/assign',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/route/create',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/route/index',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/route/refresh',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/route/remove',2,NULL,NULL,NULL,1512924431,1512924431),('/admin/rule/*',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/rule/create',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/rule/delete',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/rule/index',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/rule/update',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/rule/view',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/*',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/activate',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/change-password',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/deactivate',2,NULL,NULL,NULL,1513914178,1513914178),('/admin/user/delete',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/index',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/login',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/logout',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/request-password-reset',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/reset-password',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/signup',2,NULL,NULL,NULL,1512924432,1512924432),('/admin/user/update',2,NULL,NULL,NULL,1513914178,1513914178),('/admin/user/view',2,NULL,NULL,NULL,1512924432,1512924432),('/ajax/*',2,NULL,NULL,NULL,1526634149,1526634149),('/ajax/gettemplate/*',2,NULL,NULL,NULL,1526867608,1526867608),('/api/*',2,NULL,NULL,NULL,1518163424,1518163424),('/api/create',2,NULL,NULL,NULL,1518163424,1518163424),('/api/delete',2,NULL,NULL,NULL,1518163424,1518163424),('/api/index',2,NULL,NULL,NULL,1518163424,1518163424),('/api/options',2,NULL,NULL,NULL,1518163424,1518163424),('/api/update',2,NULL,NULL,NULL,1518163424,1518163424),('/api/view',2,NULL,NULL,NULL,1518163424,1518163424),('/capi/*',2,NULL,NULL,NULL,1533707675,1533707675),('/cashiering/*',2,NULL,NULL,NULL,1515379311,1515379311),('/copyright/*',2,NULL,NULL,NULL,1525832629,1525832629),('/copyright/default/*',2,NULL,NULL,NULL,1525832629,1525832629),('/copyright/default/index',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/*',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/default/*',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/default/index',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/info/*',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/info/create',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/info/delete',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/info/getbarangay',2,NULL,NULL,NULL,1527651993,1527651993),('/customer/info/getmunicipality',2,NULL,NULL,NULL,1527651993,1527651993),('/customer/info/getprovince',2,NULL,NULL,NULL,1527651993,1527651993),('/customer/info/index',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/info/update',2,NULL,NULL,NULL,1525832629,1525832629),('/customer/info/view',2,NULL,NULL,NULL,1525832629,1525832629),('/datecontrol/*',2,NULL,NULL,NULL,1525832636,1525832636),('/datecontrol/parse/*',2,NULL,NULL,NULL,1525832635,1525832635),('/datecontrol/parse/convert',2,NULL,NULL,NULL,1525832635,1525832635),('/dbmanager/*',2,NULL,NULL,NULL,1543971695,1543971695),('/dbmanager/config/*',2,NULL,NULL,NULL,1544073213,1544073213),('/dbmanager/default/*',2,NULL,NULL,NULL,1544073491,1544073491),('/debug/*',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/default/*',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/default/db-explain',2,NULL,NULL,NULL,1512924432,1512924432),('/debug/default/download-mail',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/default/index',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/default/toolbar',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/default/view',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/user/*',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/user/reset-identity',2,NULL,NULL,NULL,1512924433,1512924433),('/debug/user/set-identity',2,NULL,NULL,NULL,1512924433,1512924433),('/faq/*',2,NULL,NULL,NULL,1533518709,1533518709),('/feedback/default',2,NULL,NULL,NULL,1533625775,1533625775),('/finance/*',2,NULL,NULL,NULL,1522048795,1522048795),('/finance/accounting/*',2,NULL,NULL,NULL,1528947012,1528947012),('/finance/accounting/op/*',2,NULL,NULL,NULL,1533009125,1533009125),('/finance/accountingcode/*',2,NULL,NULL,NULL,1527842004,1527842004),('/finance/accountingcode/create',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcode/delete',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcode/index',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcode/mapping',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcode/update',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcode/view',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/*',2,NULL,NULL,NULL,1527842093,1527842093),('/finance/accountingcodemapping/account',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/collectionfilter',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/create',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/delete',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/dropdown',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/index',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/update',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/accountingcodemapping/view',2,NULL,NULL,NULL,1527842092,1527842092),('/finance/ar/create',2,NULL,NULL,NULL,1532331685,1532331685),('/finance/ar/getopgrid',2,NULL,NULL,NULL,1534733132,1534733132),('/finance/ar/getopgrid/*',2,NULL,NULL,NULL,1534732978,1534732978),('/finance/ar/update',2,NULL,NULL,NULL,1532331917,1532331917),('/finance/ar/view',2,NULL,NULL,NULL,1532331824,1532331824),('/finance/billing',2,NULL,NULL,NULL,1532330902,1532330902),('/finance/billing/*',2,NULL,NULL,NULL,1528962665,1528962665),('/finance/billing/client',2,NULL,NULL,NULL,1532332209,1532332209),('/finance/billing/clientcreate',2,NULL,NULL,NULL,1532332350,1532332350),('/finance/billing/clientdelete',2,NULL,NULL,NULL,1532332830,1532332830),('/finance/billing/clientupdate',2,NULL,NULL,NULL,1532332628,1532332628),('/finance/billing/clientview',2,NULL,NULL,NULL,1532332523,1532332523),('/finance/billing/index',2,NULL,NULL,NULL,1532330559,1532330559),('/finance/billing/invoices',2,NULL,NULL,NULL,1532331281,1532331281),('/finance/billing/soa',2,NULL,NULL,NULL,1532333846,1532333846),('/finance/cancelop/*',2,NULL,NULL,NULL,1532327450,1532327450),('/finance/cashier/*',2,NULL,NULL,NULL,1528945142,1528945142),('/finance/cashier/create-receipt',2,NULL,NULL,NULL,1533010017,1533010017),('/finance/cashier/deposit/*',2,NULL,NULL,NULL,1533008950,1533008950),('/finance/collectiontype/*',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/collectiontype/create',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/collectiontype/delete',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/collectiontype/index',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/collectiontype/update',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/collectiontype/view',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/customertransaction/*',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customertransaction/create',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customertransaction/delete',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customertransaction/index',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/customertransaction/update',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customertransaction/view',2,NULL,NULL,NULL,1525832627,1525832627),('/finance/customerwallet/*',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customerwallet/create',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customerwallet/delete',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customerwallet/index',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customerwallet/update',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/customerwallet/view',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/default/*',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/default/index',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/financialreports/*',2,NULL,NULL,NULL,1527842051,1527842051),('/finance/financialreports/collectionsummary',2,NULL,NULL,NULL,1527842093,1527842093),('/finance/financialreports/index',2,NULL,NULL,NULL,1527842093,1527842093),('/finance/financialreports/test',2,NULL,NULL,NULL,1527842093,1527842093),('/finance/index',2,NULL,NULL,NULL,1532323552,1532323552),('/finance/op',2,NULL,NULL,NULL,1525834028,1525834028),('/finance/op/*',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/op/add-paymentitem',2,NULL,NULL,NULL,1533021598,1533021598),('/finance/op/check-customer-wallet',2,NULL,NULL,NULL,1533019144,1533019144),('/finance/op/create',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/op/delete',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/op/getlistrequest',2,NULL,NULL,NULL,1526447329,1526447329),('/finance/op/index',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/op/listpaymentmode',2,NULL,NULL,NULL,1533019165,1533019165),('/finance/op/listrequest',2,NULL,NULL,NULL,1533018848,1533018848),('/finance/op/printview',2,NULL,NULL,NULL,1533090431,1533090431),('/finance/op/save-paymentitem',2,NULL,NULL,NULL,1533026811,1533026811),('/finance/op/update',2,NULL,NULL,NULL,1533013797,1533013797),('/finance/op/update-paymentmode',2,NULL,NULL,NULL,1534734519,1534734519),('/finance/op/updateamount',2,NULL,NULL,NULL,1533014038,1533014038),('/finance/op/view',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/opt/update',2,NULL,NULL,NULL,1525832628,1525832628),('/finance/soa/create',2,NULL,NULL,NULL,1532334263,1532334263),('/finance/soa/view',2,NULL,NULL,NULL,1532334366,1532334366),('/gii/*',2,NULL,NULL,NULL,1512924433,1512924433),('/gii/default/*',2,NULL,NULL,NULL,1512924433,1512924433),('/gii/default/action',2,NULL,NULL,NULL,1512924433,1512924433),('/gii/default/diff',2,NULL,NULL,NULL,1512924433,1512924433),('/gii/default/index',2,NULL,NULL,NULL,1512924433,1512924433),('/gii/default/preview',2,NULL,NULL,NULL,1512924433,1512924433),('/gii/default/view',2,NULL,NULL,NULL,1512924433,1512924433),('/gridview/*',2,NULL,NULL,NULL,1516673162,1516673162),('/gridview/export/*',2,NULL,NULL,NULL,1516673161,1516673161),('/gridview/export/download',2,NULL,NULL,NULL,1516673160,1516673160),('/help/*',2,NULL,NULL,NULL,1533521746,1533521746),('/help/faqs/*',2,NULL,NULL,NULL,1533521862,1533521862),('/help/feedback/*',2,NULL,NULL,NULL,1533626809,1533626809),('/imagemanager/*',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/default/*',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/default/index',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/manager/*',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/manager/crop',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/manager/delete',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/manager/get-original-image',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/manager/index',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/manager/upload',2,NULL,NULL,NULL,1516673162,1516673162),('/imagemanager/manager/view',2,NULL,NULL,NULL,1516673162,1516673162),('/inventory/*',2,NULL,NULL,NULL,1515133710,1515133710),('/inventory/categorytype/*',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/categorytype/create',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/categorytype/delete',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/categorytype/index',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/categorytype/update',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/categorytype/view',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/default/*',2,NULL,NULL,NULL,1516673162,1516673162),('/inventory/default/index',2,NULL,NULL,NULL,1516673162,1516673162),('/inventory/inventoryentries/*',2,NULL,NULL,NULL,1542358526,1542358526),('/inventory/inventoryentries/withdraw/*',2,NULL,NULL,NULL,1542358608,1542358608),('/inventory/products/*',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/add-inventory-entries',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/add-inventory-withdrawaldetails',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/create',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/delete',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/index',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/pdf',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/update',2,NULL,NULL,NULL,1517209185,1517209185),('/inventory/products/view',2,NULL,NULL,NULL,1517209185,1517209185),('/lab/*',2,NULL,NULL,NULL,1514814971,1514814971),('/lab/default/*',2,NULL,NULL,NULL,1516673162,1516673162),('/lab/default/index',2,NULL,NULL,NULL,1516673162,1516673162),('/lab/lab/*',2,NULL,NULL,NULL,1525832626,1525832626),('/lab/lab/create',2,NULL,NULL,NULL,1525832626,1525832626),('/lab/lab/delete',2,NULL,NULL,NULL,1525832626,1525832626),('/lab/lab/index',2,NULL,NULL,NULL,1525832626,1525832626),('/lab/lab/update',2,NULL,NULL,NULL,1525832626,1525832626),('/lab/lab/view',2,NULL,NULL,NULL,1525832626,1525832626),('/lab/labsampletype/*',2,NULL,NULL,NULL,1532667857,1532667857),('/lab/methodreference/*',2,NULL,NULL,NULL,1532668411,1532668411),('/lab/request',2,NULL,NULL,NULL,1526024300,1526024300),('/lab/request/*',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/request/create',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/request/delete',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/request/index',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/request/update',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/request/view',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sample/*',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sample/create',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sample/delete',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sample/generatesamplecode',2,NULL,NULL,NULL,1527651993,1527651993),('/lab/sample/getlisttemplate',2,NULL,NULL,NULL,1526447329,1526447329),('/lab/sample/index',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sample/listsampletype',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sample/listtemplate',2,NULL,NULL,NULL,1526447329,1526447329),('/lab/sample/update',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sample/view',2,NULL,NULL,NULL,1525832627,1525832627),('/lab/sampletype/*',2,NULL,NULL,NULL,1532668071,1532668071),('/lab/sampletypetestname/*',2,NULL,NULL,NULL,1532668347,1532668347),('/lab/tagging/*',2,NULL,NULL,NULL,1531116149,1531116149),('/lab/testname/*',2,NULL,NULL,NULL,1532668438,1532668438),('/lab/testnamemethod/*',2,NULL,NULL,NULL,1532668390,1532668390),('/lsync/*',2,NULL,NULL,NULL,1536279695,1536279695),('/maintenance/*',2,NULL,NULL,NULL,1514539173,1514539173),('/maintenance/index',2,NULL,NULL,NULL,1514539139,1514539139),('/message/*',2,NULL,NULL,NULL,1515721342,1515721342),('/message/message/*',2,NULL,NULL,NULL,1515721342,1515721342),('/message/message/check-for-new-messages',2,NULL,NULL,NULL,1515721341,1515721341),('/message/message/compose',2,NULL,NULL,NULL,1515721342,1515721342),('/message/message/delete',2,NULL,NULL,NULL,1515721342,1515721342),('/message/message/ignorelist',2,NULL,NULL,NULL,1515721341,1515721341),('/message/message/inbox',2,NULL,NULL,NULL,1515721341,1515721341),('/message/message/mark-all-as-read',2,NULL,NULL,NULL,1515721342,1515721342),('/message/message/sent',2,NULL,NULL,NULL,1515721341,1515721341),('/message/message/view',2,NULL,NULL,NULL,1515721342,1515721342),('/module/*',2,NULL,NULL,NULL,1514431824,1514431824),('/module/createmodule',2,NULL,NULL,NULL,1515390508,1515390508),('/module/deletedetails',2,NULL,NULL,NULL,1527641231,1527641231),('/module/details',2,NULL,NULL,NULL,1527641231,1527641231),('/module/detailscreate',2,NULL,NULL,NULL,1527641231,1527641231),('/module/export',2,NULL,NULL,NULL,1515390508,1515390508),('/module/extract',2,NULL,NULL,NULL,1515054294,1515054294),('/module/getcss',2,NULL,NULL,NULL,1515721342,1515721342),('/module/index',2,NULL,NULL,NULL,1514431824,1514431824),('/module/manager',2,NULL,NULL,NULL,1515721342,1515721342),('/module/removemodule',2,NULL,NULL,NULL,1515390508,1515390508),('/module/update',2,NULL,NULL,NULL,1515721342,1515721342),('/module/upload',2,NULL,NULL,NULL,1515390507,1515390507),('/module/view',2,NULL,NULL,NULL,1515721342,1515721342),('/module/viewdetails',2,NULL,NULL,NULL,1527641231,1527641231),('/module/viewpackage',2,NULL,NULL,NULL,1527641231,1527641231),('/module/writeini',2,NULL,NULL,NULL,1515054294,1515054294),('/packagedetails/*',2,NULL,NULL,NULL,1522742054,1522742054),('/pdfjs/*',2,NULL,NULL,NULL,1527038139,1527038139),('/pdfjs/default/*',2,NULL,NULL,NULL,1527038139,1527038139),('/pdfjs/default/index',2,NULL,NULL,NULL,1527038139,1527038139),('/profile/info/*',2,NULL,NULL,NULL,1513914178,1513914178),('/profile/info/create',2,NULL,NULL,NULL,1513914178,1513914178),('/profile/info/delete',2,NULL,NULL,NULL,1513914178,1513914178),('/profile/info/deleteimage',2,NULL,NULL,NULL,1514536468,1514536468),('/profile/info/index',2,NULL,NULL,NULL,1513914178,1513914178),('/profile/info/update',2,NULL,NULL,NULL,1513914178,1513914178),('/profile/info/uploadPhoto',2,NULL,NULL,NULL,1513930949,1513930949),('/profile/info/view',2,NULL,NULL,NULL,1513914178,1513914178),('/referral/*',2,NULL,NULL,NULL,1536722576,1536722576),('/reportico/*',2,NULL,NULL,NULL,1526523804,1526523804),('/reportico/default/*',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/default/index',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/default/login',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/mode/*',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/mode/admin',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/mode/execute',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/mode/menu',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/mode/prepare',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/mode/reportico',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/reportico/*',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/reportico/ajax',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/reportico/dbimage',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/reportico/graph',2,NULL,NULL,NULL,1527651993,1527651993),('/reportico/reportico/reportico',2,NULL,NULL,NULL,1527651993,1527651993),('/reports/*',2,NULL,NULL,NULL,1527038132,1527038132),('/reports/default/*',2,NULL,NULL,NULL,1527651994,1527651994),('/reports/default/index',2,NULL,NULL,NULL,1527651994,1527651994),('/reports/preview/*',2,NULL,NULL,NULL,1527651994,1527651994),('/reports/preview/index',2,NULL,NULL,NULL,1527651994,1527651994),('/sample/*',2,NULL,NULL,NULL,1515141962,1515141962),('/services/*',2,NULL,NULL,NULL,1523954885,1523954885),('/services/default/*',2,NULL,NULL,NULL,1525832628,1525832628),('/services/default/index',2,NULL,NULL,NULL,1525832628,1525832628),('/services/linux',2,NULL,NULL,NULL,1524206211,1524206211),('/services/lookup',2,NULL,NULL,NULL,1524205056,1524205056),('/services/packagelist/*',2,NULL,NULL,NULL,1527648563,1527648563),('/services/packagelist/create',2,NULL,NULL,NULL,1527651993,1527651993),('/services/packagelist/delete',2,NULL,NULL,NULL,1527651993,1527651993),('/services/packagelist/index',2,NULL,NULL,NULL,1527651993,1527651993),('/services/packagelist/update',2,NULL,NULL,NULL,1527651993,1527651993),('/services/packagelist/view',2,NULL,NULL,NULL,1527651993,1527651993),('/services/procedure/*',2,NULL,NULL,NULL,1527842093,1527842093),('/services/procedure/create',2,NULL,NULL,NULL,1527842093,1527842093),('/services/procedure/delete',2,NULL,NULL,NULL,1527842093,1527842093),('/services/procedure/index',2,NULL,NULL,NULL,1527842093,1527842093),('/services/procedure/update',2,NULL,NULL,NULL,1527842093,1527842093),('/services/procedure/view',2,NULL,NULL,NULL,1527842093,1527842093),('/services/sampletype/*',2,NULL,NULL,NULL,1525832628,1525832628),('/services/sampletype/create',2,NULL,NULL,NULL,1525832628,1525832628),('/services/sampletype/delete',2,NULL,NULL,NULL,1525832628,1525832628),('/services/sampletype/index',2,NULL,NULL,NULL,1525832628,1525832628),('/services/sampletype/update',2,NULL,NULL,NULL,1525832628,1525832628),('/services/sampletype/view',2,NULL,NULL,NULL,1525832628,1525832628),('/services/test/*',2,NULL,NULL,NULL,1524128210,1524128210),('/services/test/create',2,NULL,NULL,NULL,1525832628,1525832628),('/services/test/delete',2,NULL,NULL,NULL,1525832628,1525832628),('/services/test/index',2,NULL,NULL,NULL,1525832628,1525832628),('/services/test/update',2,NULL,NULL,NULL,1525832628,1525832628),('/services/test/view',2,NULL,NULL,NULL,1525832628,1525832628),('/services/testcategory/*',2,NULL,NULL,NULL,1524128341,1524128341),('/services/testcategory/create',2,NULL,NULL,NULL,1525832629,1525832629),('/services/testcategory/delete',2,NULL,NULL,NULL,1525832629,1525832629),('/services/testcategory/index',2,NULL,NULL,NULL,1525832628,1525832628),('/services/testcategory/update',2,NULL,NULL,NULL,1525832629,1525832629),('/services/testcategory/view',2,NULL,NULL,NULL,1525832629,1525832629),('/services/workflow/*',2,NULL,NULL,NULL,1525835145,1525835145),('/services/workflow/create',2,NULL,NULL,NULL,1525835760,1525835760),('/services/workflow/delete',2,NULL,NULL,NULL,1525835768,1525835768),('/services/workflow/index',2,NULL,NULL,NULL,1525835778,1525835778),('/services/workflow/update',2,NULL,NULL,NULL,1525835785,1525835785),('/services/workflow/view',2,NULL,NULL,NULL,1525835811,1525835811),('/settings/*',2,NULL,NULL,NULL,1514536468,1514536468),('/settings/disable',2,NULL,NULL,NULL,1514536468,1514536468),('/settings/enable',2,NULL,NULL,NULL,1514536468,1514536468),('/settings/index',2,NULL,NULL,NULL,1514536468,1514536468),('/site/*',2,NULL,NULL,NULL,1512923763,1512923763),('/site/about',2,NULL,NULL,NULL,1513840641,1513840641),('/site/captcha',2,NULL,NULL,NULL,1513840641,1513840641),('/site/contact',2,NULL,NULL,NULL,1513840641,1513840641),('/site/error',2,NULL,NULL,NULL,1512924433,1512924433),('/site/index',2,NULL,NULL,NULL,1512924433,1512924433),('/site/login',2,NULL,NULL,NULL,1512924433,1512924433),('/site/logout',2,NULL,NULL,NULL,1512924433,1512924433),('/site/query',2,NULL,NULL,NULL,1518163424,1518163424),('/site/request-password-reset',2,NULL,NULL,NULL,1513840641,1513840641),('/site/requestpasswordreset',2,NULL,NULL,NULL,1516091491,1516091491),('/site/reset-password',2,NULL,NULL,NULL,1514249865,1514249865),('/site/retrievechart',2,NULL,NULL,NULL,1525832629,1525832629),('/site/retrievecolumn',2,NULL,NULL,NULL,1525832629,1525832629),('/site/sendmail',2,NULL,NULL,NULL,1516091490,1516091490),('/site/signup',2,NULL,NULL,NULL,1513840641,1513840641),('/site/success',2,NULL,NULL,NULL,1516091491,1516091491),('/site/upload',2,NULL,NULL,NULL,1513930949,1513930949),('/site/userdashboard',2,NULL,NULL,NULL,1526447329,1526447329),('/site/verify',2,NULL,NULL,NULL,1516091491,1516091491),('/system/*',2,NULL,NULL,NULL,1525832629,1525832629),('/system/api-config',2,NULL,NULL,NULL,1536285508,1536285508),('/system/configurations/create',2,NULL,NULL,NULL,1526877154,1526877154),('/system/configurations/delete',2,NULL,NULL,NULL,1526877166,1526877166),('/system/configurations/index',2,NULL,NULL,NULL,1526877154,1526877154),('/system/configurations/update',2,NULL,NULL,NULL,1526877154,1526877154),('/system/configurations/view',2,NULL,NULL,NULL,1526877154,1526877154),('/system/create',2,NULL,NULL,NULL,1525832629,1525832629),('/system/delete',2,NULL,NULL,NULL,1525832629,1525832629),('/system/index',2,NULL,NULL,NULL,1525832629,1525832629),('/system/pdf',2,NULL,NULL,NULL,1527651994,1527651994),('/system/update',2,NULL,NULL,NULL,1525832629,1525832629),('/system/view',2,NULL,NULL,NULL,1525832629,1525832629),('/tagging/default/*',2,NULL,NULL,NULL,1516673162,1516673162),('/tagging/default/index',2,NULL,NULL,NULL,1516673162,1516673162),('/test2/*',2,NULL,NULL,NULL,1516085459,1516085459),('/test3/*',2,NULL,NULL,NULL,1516085788,1516085788),('/tt/*',2,NULL,NULL,NULL,1516086131,1516086131),('/uploads/*',2,NULL,NULL,NULL,1514350073,1514350073),('/user/*',2,NULL,NULL,NULL,1513843345,1513843345),('/user/create',2,NULL,NULL,NULL,1513843345,1513843345),('/user/delete',2,NULL,NULL,NULL,1513843345,1513843345),('/user/index',2,NULL,NULL,NULL,1513843344,1513843344),('/user/update',2,NULL,NULL,NULL,1513843345,1513843345),('/user/view',2,NULL,NULL,NULL,1513843344,1513843344),('access-accounting',2,'This permission allow user to access Accounting Submodule',NULL,NULL,1515371555,1528947012),('access-accounting-code',2,'This permission allow user to access Accounting Code Submodule',NULL,NULL,1527842004,1527842004),('access-ajax',2,'Permission to access ajax ',NULL,NULL,1526634127,1526634127),('access-api',2,'Access on API Permissions',NULL,NULL,1518163478,1518163478),('access-api-config',2,'Permission that can access API Configurations',NULL,NULL,1536285472,1536285472),('access-assignment',2,'Permission will allow user to access assignment',NULL,NULL,1514425828,1514425828),('access-billing',2,'This permission allow user to access Billing Submodule',NULL,NULL,1528962665,1528962665),('access-capiop',2,'permission test for cap/op',NULL,NULL,1533707713,1533707713),('access-configure-template',2,'permission that will allow access or modify on Configuration Template',NULL,NULL,1526877084,1526877084),('access-customer',2,'This permission allow user to access customer module',NULL,NULL,1524196419,1524196419),('access-customer-info',2,'Permission to access customer info module',NULL,NULL,1527733977,1527733977),('access-customer-wallet',2,'Permission to access Customer Wallet',NULL,NULL,1523943200,1523943200),('access-customers',2,'Customer',NULL,NULL,1525831486,1525831486),('access-db-config',2,'Permissions to access DB Manager configuration module',NULL,NULL,1544073310,1544073310),('access-db-manager',2,'Permission to access DB Manager Module',NULL,NULL,1543971741,1543971741),('access-debug',2,'This Permission allow user to access debug module',NULL,NULL,1513840103,1513840103),('access-deposit',2,'This permission allow user to access Deposit Submodule',NULL,NULL,1533008950,1533008950),('access-entries',2,'This permission allow user to access Entries Submodule',NULL,NULL,1542358526,1542358526),('access-faqs',2,'This permission allow user to access FAQs Submodule',NULL,NULL,1533521862,1533521862),('access-feedback',2,'This permission allow user to access Feedback Submodule',NULL,NULL,1533625803,1533626809),('access-finance',2,'This permission allow user to access finance module',NULL,NULL,1522048795,1522048795),('access-financial-reports',2,'This permission allow user to access Financial Reports Submodule',NULL,NULL,1527842051,1527842051),('access-gii',2,'This permission allow user to access GII Tool',NULL,NULL,1513839929,1513839929),('access-help',2,'This permission allow user to access help module',NULL,NULL,1533521746,1533521746),('access-his-profile',2,'This permission will only allow user access on his own profile',NULL,NULL,1513925187,1513925187),('access-inventory',2,'This permission allow user to access inventory module',NULL,NULL,1515133710,1515133710),('access-lab',2,'This permission allow user to access Lab Submodule',NULL,NULL,1514815010,1527647944),('access-lab-sample-type',2,'This permission allow user to access Lab Sample Type Submodule',NULL,NULL,1532667857,1532667857),('access-Linux',2,'This permission allow user to access Linux Submodule',NULL,NULL,1524206211,1524206211),('access-lookup',2,'This permission allow user to access lookup Submodule',NULL,NULL,1524205056,1524205056),('access-menu',2,'Permission to allow access menu ',NULL,NULL,1514426762,1514426762),('access-message',2,'This permssion allow user to access message module',NULL,NULL,1515721386,1515721386),('access-method-reference',2,'This permission allow user to access Method Reference Submodule',NULL,NULL,1532668411,1532668411),('access-module',2,'This permission allow user to access package manager',NULL,NULL,1514431815,1514431815),('access-op-grid',2,'access op grid ajax url',NULL,NULL,1534733164,1534733164),('access-op(non-lab)',2,'This permission allow user to access OP(Non-Lab) Submodule',NULL,NULL,1533009125,1533009125),('access-opgrid',2,'permission to access op grid',NULL,NULL,1534733009,1534733009),('access-order-of-payment',2,'This permission allow user to access Order of Payment Submodule',NULL,NULL,1525834028,1525834028),('access-package',2,'This permission allow user to access Package Submodule',NULL,NULL,1527648563,1527648563),('access-package-list',2,'Allow Users to access package list',NULL,NULL,1515486771,1515486771),('access-packagedetails',2,'this will allow access on package details',NULL,NULL,1522742254,1522742254),('access-pdfjs',2,'Permission to access PDFJS',NULL,NULL,1527038272,1527038272),('access-permission',2,'Permission to access permission',NULL,NULL,1514426671,1514426671),('access-procurement',2,'This permission allow user to access procurement module',NULL,NULL,1519980796,1519980796),('access-products',2,'This permission allow user to access Products Submodule',NULL,NULL,1542354270,1542354270),('access-profile',2,'This permission allow users access on Profile',NULL,NULL,1513924948,1513924948),('access-rbac',2,'This permission allow users to access RBAC but depends on other permissions to access other features of RBAC.',NULL,NULL,1514364821,1514364821),('access-receipt',2,'This permission allow user to access Cashier Submodule',NULL,NULL,1528945142,1528945142),('access-referral',2,'This permission allow user to access referral module',NULL,NULL,1536722576,1536722576),('access-reportico',2,NULL,NULL,NULL,1526523865,1526523865),('access-reports',2,'Permission to access Report module',NULL,NULL,1527038110,1527038110),('access-request',2,'Permission to access Request submodule',NULL,NULL,1526447361,1526447361),('access-role',2,'Permission to allow access role',NULL,NULL,1514426382,1514426382),('access-route',2,'Permission to allow access route',NULL,NULL,1514425999,1514425999),('access-rule',2,'Permission to access Rule',NULL,NULL,1514426816,1514426896),('access-sample',2,'This permission allow user to access sample module',NULL,NULL,1515141962,1515141962),('access-sample-type',2,'Access on sample type submodule',NULL,NULL,1525836180,1525836180),('access-sample-type-test-name',2,'This permission allow user to access Sample Type Test Name Submodule',NULL,NULL,1532668347,1532668347),('access-sample-types',2,'This permission allow user to access Sample Types Submodule',NULL,NULL,1532668071,1532668071),('access-services',2,'This permission allow user to access services module',NULL,NULL,1523954885,1523954885),('access-settings',2,'This permission allows user to access settings',NULL,NULL,1514536456,1514536456),('access-signup',2,'This permission allow user to signup',NULL,NULL,1513840579,1513840579),('access-system',2,'Permission that will grant access on system module',NULL,NULL,1526450607,1526450607),('access-tagging',2,'This permission allow user to access Tagging Submodule',NULL,NULL,1531116149,1531116149),('access-test',2,'This permission allow user to access test module',NULL,NULL,1516084596,1516084596),('access-test-category',2,'access-test category',NULL,NULL,1524128108,1524128108),('access-test-name',2,'This permission allow user to access Test Name Submodule',NULL,NULL,1532668438,1532668438),('access-test-name-method',2,'This permission allow user to access Test Name Method Submodule',NULL,NULL,1532668390,1532668390),('access-tt',2,'This permission allow user to access tt module',NULL,NULL,1516086131,1516086131),('access-user',2,'This permission allow user to access User Account',NULL,NULL,1514425679,1514425679),('access-withdrawal',2,'This permission allow user to access Withdrawal Submodule',NULL,NULL,1542358608,1542358608),('access-workflow-management',2,'This permission allow user to access Workflow Management Submodule',NULL,NULL,1525835145,1525835145),('Accountant',1,'will have the privilege of full control of accounting module',NULL,NULL,1527842561,1527842561),('Agency Head',1,'Have the Privilege to review and monitor and finalized approval of laboratory reports using e-signatures',NULL,NULL,1527842278,1527842278),('allow-access-backend',2,'This Permission allow users to access backend',NULL,NULL,1513908976,1513908976),('allow-cancel-op',2,'Permission that will allow cancel of OP',NULL,NULL,1532327395,1532327395),('allow-cancel-request',2,'Allow Cancel Request',NULL,NULL,1532325785,1532325785),('allow-create-op',2,'Permission to create OP',NULL,NULL,1533009750,1533009750),('allow-create-receipt',2,'Permission to create receipt.',NULL,NULL,1533009941,1533009941),('allow-delete-customer',2,'Allow to delete customer',NULL,NULL,1525832791,1525832791),('allow-delete-workflow',2,'Allow deletion of workflow',NULL,NULL,1525835895,1525835895),('allow-get-request',2,'Permission to allow get list of request',NULL,NULL,1533018524,1533018524),('allow-gridview-export',2,'this permissions will allow access export/download',NULL,NULL,1517209167,1517209167),('allow-on-account-delete',2,'Permission to allow deletion of on account',NULL,NULL,1532332873,1532332873),('allow-sync',2,'Permission to allow database sync',NULL,NULL,1536279684,1536279684),('allow-update-op',2,'Permission to update OP',NULL,NULL,1533013632,1533013632),('allow-update-paymentitem',2,'Permission to update payment item.',NULL,NULL,1533013990,1533013990),('allow-view-op',2,'Permission to view OP',NULL,NULL,1533013864,1533013864),('Analyst',1,'Laboratory Analyst',NULL,NULL,1525835384,1525835384),('basic-role',1,'Basic role for newly created user',NULL,NULL,1517967802,1517967802),('can-delete-profile',2,'This permission allow user to delete profile',NULL,NULL,1514428789,1514428789),('Cashier',1,'Cashier for OP',NULL,NULL,1532327314,1532327314),('Cashier Manager',1,'will have the privilege to have a full control of finance module including the access to make billings and order of payment ',NULL,NULL,1527842404,1527842404),('create-bill-invoice',2,'Permission to create Bill Invoice',NULL,NULL,1532331229,1532331229),('create-code-mapping',2,'Permission that will create code mapping',NULL,NULL,1532396338,1532396338),('create-customer-wallet',2,'Permission that will create Customer Wallet',NULL,NULL,1532335532,1532335532),('create-on-account',2,'Permission that will create on account',NULL,NULL,1532332380,1532332380),('create-soa',2,'Permission that will create Statement of Account',NULL,NULL,1532334300,1532334300),('CRO',1,'Customer Relations Officer',NULL,NULL,1525832980,1525832980),('Guest',1,'This the default Role',NULL,NULL,1517381088,1517381088),('lab-manager',1,'This is a role for Laboratory Manager',NULL,NULL,1516858383,1516858383),('manage-on-account',2,'Permission that will manage account',NULL,NULL,1532332237,1532332237),('manage-soa',2,'Manage Statement of Account ',NULL,NULL,1532333889,1532333889),('profile-full-access',2,'This permission allow users to access profile with full access',NULL,NULL,1513914161,1513914161),('rbac-assign-permission',2,'This permission allows user to assign roles',NULL,NULL,1512924223,1513840446),('rbac-full-access',2,'This permission has all the rights to access rbac',NULL,NULL,1513840364,1513840364),('super-administrator',1,'This role reserve all the rights and permissions',NULL,NULL,1513838897,1513840008),('update-bill-invoice',2,'Permission that will update invoices',NULL,NULL,1532331947,1532331947),('update-on-account',2,'Permission that will update on account',NULL,NULL,1532332688,1532332688),('user-full-access',2,'This Permission allows user to access User module',NULL,NULL,1513843398,1513843398),('view-all-rstl',2,'Permission to access all RSTL data',NULL,NULL,1532922388,1532922388),('view-bill-invoice',2,'Permission to View Bill Invoices',NULL,NULL,1532331361,1532331361),('view-customer-wallet',2,'Permission to view customer wallet',NULL,NULL,1532335612,1532335612),('view-on-account',2,'permission that will allow view on account',NULL,NULL,1532332482,1532332482),('view-soa',2,'Permission that will allow to view Statement of Account',NULL,NULL,1532334393,1532334393);
/*!40000 ALTER TABLE `tbl_auth_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_auth_item_child`
--

DROP TABLE IF EXISTS `tbl_auth_item_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `tbl_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `tbl_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `tbl_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_auth_item_child`
--

LOCK TABLES `tbl_auth_item_child` WRITE;
/*!40000 ALTER TABLE `tbl_auth_item_child` DISABLE KEYS */;
INSERT INTO `tbl_auth_item_child` (`parent`, `child`) VALUES ('access-accounting','/accounting/*'),('rbac-full-access','/admin/*'),('rbac-assign-permission','/admin/assignment/*'),('access-assignment','/admin/assignment/index'),('access-assignment','/admin/assignment/view'),('access-rbac','/admin/assignment/view'),('access-menu','/admin/menu/index'),('access-menu','/admin/menu/view'),('access-permission','/admin/permission/index'),('access-permission','/admin/permission/view'),('access-role','/admin/role/index'),('access-role','/admin/role/view'),('access-route','/admin/route/assign'),('access-route','/admin/route/index'),('access-rule','/admin/rule/index'),('access-rule','/admin/rule/view'),('access-user','/admin/user/*'),('access-ajax','/ajax/*'),('basic-role','/ajax/*'),('basic-role','/ajax/gettemplate/*'),('access-api','/api/*'),('access-capiop','/capi/*'),('access-customer-info','/customer/info/*'),('access-customers','/customer/info/create'),('allow-delete-customer','/customer/info/delete'),('access-customers','/customer/info/index'),('access-customers','/customer/info/update'),('access-customers','/customer/info/view'),('access-db-config','/dbmanager/config/*'),('access-db-manager','/dbmanager/default/*'),('access-debug','/debug/*'),('access-accounting','/finance/accounting/*'),('access-op(non-lab)','/finance/accounting/op/*'),('access-accounting-code','/finance/accountingcode/*'),('access-accounting-code','/finance/accountingcodemapping/*'),('create-bill-invoice','/finance/ar/create'),('access-op-grid','/finance/ar/getopgrid'),('access-op-grid','/finance/ar/getopgrid/*'),('access-opgrid','/finance/ar/getopgrid/*'),('update-bill-invoice','/finance/ar/update'),('view-bill-invoice','/finance/ar/view'),('access-billing','/finance/billing'),('manage-on-account','/finance/billing/client'),('create-on-account','/finance/billing/clientcreate'),('allow-on-account-delete','/finance/billing/clientdelete'),('update-on-account','/finance/billing/clientupdate'),('view-on-account','/finance/billing/clientview'),('access-billing','/finance/billing/index'),('create-bill-invoice','/finance/billing/invoices'),('view-bill-invoice','/finance/billing/invoices'),('manage-soa','/finance/billing/soa'),('allow-cancel-op','/finance/cancelop/*'),('access-receipt','/finance/cashier/*'),('allow-create-receipt','/finance/cashier/create-receipt'),('access-deposit','/finance/cashier/deposit/*'),('create-customer-wallet','/finance/customerwallet/create'),('access-customer-wallet','/finance/customerwallet/index'),('view-customer-wallet','/finance/customerwallet/view'),('access-finance','/finance/default/index'),('access-financial-reports','/finance/financialreports/*'),('Accountant','/finance/op/add-paymentitem'),('Cashier','/finance/op/add-paymentitem'),('Cashier Manager','/finance/op/add-paymentitem'),('CRO','/finance/op/add-paymentitem'),('Accountant','/finance/op/check-customer-wallet'),('Cashier','/finance/op/check-customer-wallet'),('Cashier Manager','/finance/op/check-customer-wallet'),('CRO','/finance/op/check-customer-wallet'),('allow-create-op','/finance/op/create'),('allow-get-request','/finance/op/getlistrequest'),('access-order-of-payment','/finance/op/index'),('Accountant','/finance/op/listpaymentmode'),('Cashier','/finance/op/listpaymentmode'),('Cashier Manager','/finance/op/listpaymentmode'),('CRO','/finance/op/listpaymentmode'),('Accountant','/finance/op/printview'),('Cashier','/finance/op/printview'),('Cashier Manager','/finance/op/printview'),('CRO','/finance/op/printview'),('Accountant','/finance/op/save-paymentitem'),('Cashier','/finance/op/save-paymentitem'),('Cashier Manager','/finance/op/save-paymentitem'),('CRO','/finance/op/save-paymentitem'),('allow-update-op','/finance/op/update'),('allow-view-op','/finance/op/update-paymentmode'),('allow-update-paymentitem','/finance/op/updateamount'),('allow-view-op','/finance/op/view'),('create-soa','/finance/soa/create'),('view-soa','/finance/soa/view'),('access-gii','/gii/*'),('allow-gridview-export','/gridview/*'),('access-help','/help/*'),('access-faqs','/help/faqs/*'),('access-feedback','/help/feedback/*'),('access-inventory','/inventory/*'),('access-entries','/inventory/inventoryentries/*'),('access-withdrawal','/inventory/inventoryentries/withdraw/*'),('access-products','/inventory/products/*'),('access-lab','/lab/*'),('access-lab-sample-type','/lab/labsampletype/*'),('access-method-reference','/lab/methodreference/*'),('access-request','/lab/request/create'),('allow-cancel-request','/lab/request/delete'),('access-request','/lab/request/index'),('allow-cancel-request','/lab/request/index'),('access-sample-types','/lab/sampletype/*'),('access-sample-type-test-name','/lab/sampletypetestname/*'),('access-tagging','/lab/tagging/*'),('access-test-name','/lab/testname/*'),('access-test-name-method','/lab/testnamemethod/*'),('allow-sync','/lsync/*'),('Guest','/maintenance/*'),('access-message','/message/*'),('access-module','/module/*'),('access-module','/module/createmodule'),('access-module','/module/export'),('access-module','/module/extract'),('access-module','/module/index'),('access-module','/module/removemodule'),('access-module','/module/upload'),('access-module','/module/writeini'),('access-packagedetails','/packagedetails/*'),('access-pdfjs','/pdfjs/*'),('basic-role','/pdfjs/*'),('basic-role','/pdfjs/default/*'),('basic-role','/pdfjs/default/index'),('access-his-profile','/profile/info/*'),('profile-full-access','/profile/info/*'),('can-delete-profile','/profile/info/delete'),('access-his-profile','/profile/info/update'),('profile-full-access','/profile/info/update'),('profile-full-access','/profile/info/uploadPhoto'),('access-profile','/profile/info/view'),('access-referral','/referral/*'),('access-reportico','/reportico/*'),('access-reports','/reports/*'),('access-sample','/sample/*'),('access-services','/services/*'),('access-Linux','/services/linux'),('access-package','/services/packagelist/*'),('access-sample-type','/services/sampletype/*'),('access-test','/services/test/*'),('access-test-category','/services/testcategory/*'),('access-workflow-management','/services/workflow/create'),('allow-delete-workflow','/services/workflow/delete'),('access-workflow-management','/services/workflow/index'),('access-workflow-management','/services/workflow/update'),('access-workflow-management','/services/workflow/view'),('access-settings','/settings/*'),('Guest','/site/*'),('access-signup','/site/signup'),('super-administrator','/site/signup'),('profile-full-access','/site/upload'),('access-system','/system/*'),('access-api-config','/system/api-config'),('access-system','/system/create'),('access-system','/system/delete'),('access-system','/system/index'),('access-system','/system/update'),('access-system','/system/view'),('access-tt','/tt/*'),('user-full-access','/user/*'),('Accountant','access-accounting'),('Accountant','access-accounting-code'),('Guest','access-api'),('Cashier','access-billing'),('Cashier Manager','access-billing'),('super-administrator','access-configure-template'),('CRO','access-customer'),('super-administrator','access-customer'),('basic-role','access-customer-info'),('Cashier','access-customer-wallet'),('Cashier Manager','access-customer-wallet'),('super-administrator','access-customer-wallet'),('CRO','access-customers'),('super-administrator','access-customers'),('super-administrator','access-db-config'),('super-administrator','access-db-manager'),('super-administrator','access-debug'),('Cashier','access-deposit'),('Cashier Manager','access-deposit'),('CRO','access-entries'),('basic-role','access-faqs'),('basic-role','access-feedback'),('Accountant','access-finance'),('Cashier','access-finance'),('Cashier Manager','access-finance'),('CRO','access-finance'),('super-administrator','access-finance'),('super-administrator','access-financial-reports'),('super-administrator','access-gii'),('basic-role','access-help'),('Accountant','access-his-profile'),('basic-role','access-his-profile'),('super-administrator','access-inventory'),('Analyst','access-lab'),('CRO','access-lab'),('super-administrator','access-lab'),('Analyst','access-lab-sample-type'),('lab-manager','access-lab-sample-type'),('super-administrator','access-menu'),('basic-role','access-message'),('super-administrator','access-message'),('Analyst','access-method-reference'),('lab-manager','access-method-reference'),('super-administrator','access-module'),('basic-role','access-op-grid'),('Accountant','access-op(non-lab)'),('basic-role','access-opgrid'),('Cashier','access-order-of-payment'),('Cashier Manager','access-order-of-payment'),('CRO','access-order-of-payment'),('super-administrator','access-order-of-payment'),('super-administrator','access-package'),('super-administrator','access-package-list'),('super-administrator','access-packagedetails'),('CRO','access-pdfjs'),('super-administrator','access-pdfjs'),('super-administrator','access-permission'),('CRO','access-products'),('profile-full-access','access-profile'),('super-administrator','access-profile'),('super-administrator','access-rbac'),('Cashier','access-receipt'),('Cashier Manager','access-receipt'),('super-administrator','access-referral'),('super-administrator','access-reportico'),('lab-manager','access-reports'),('CRO','access-request'),('lab-manager','access-request'),('super-administrator','access-request'),('super-administrator','access-role'),('super-administrator','access-route'),('super-administrator','access-rule'),('Analyst','access-sample'),('super-administrator','access-sample'),('Analyst','access-sample-type'),('super-administrator','access-sample-type'),('Analyst','access-sample-type-test-name'),('lab-manager','access-sample-type-test-name'),('Analyst','access-sample-types'),('lab-manager','access-sample-types'),('lab-manager','access-services'),('super-administrator','access-services'),('super-administrator','access-settings'),('Guest','access-signup'),('super-administrator','access-signup'),('super-administrator','access-system'),('Analyst','access-tagging'),('lab-manager','access-tagging'),('lab-manager','access-test'),('lab-manager','access-test-category'),('super-administrator','access-test-category'),('Analyst','access-test-name'),('lab-manager','access-test-name'),('Analyst','access-test-name-method'),('lab-manager','access-test-name-method'),('super-administrator','access-user'),('CRO','access-withdrawal'),('lab-manager','access-workflow-management'),('super-administrator','access-workflow-management'),('super-administrator','Accountant'),('super-administrator','allow-access-backend'),('Cashier Manager','allow-cancel-op'),('lab-manager','allow-cancel-request'),('Accountant','allow-create-op'),('CRO','allow-create-op'),('Cashier','allow-create-receipt'),('Cashier Manager','allow-create-receipt'),('super-administrator','allow-delete-customer'),('lab-manager','allow-delete-workflow'),('Accountant','allow-get-request'),('Cashier','allow-get-request'),('Cashier Manager','allow-get-request'),('CRO','allow-get-request'),('basic-role','allow-gridview-export'),('Cashier','allow-gridview-export'),('super-administrator','allow-gridview-export'),('Cashier Manager','allow-on-account-delete'),('super-administrator','allow-sync'),('Accountant','allow-update-op'),('Cashier','allow-update-op'),('Cashier Manager','allow-update-op'),('CRO','allow-update-op'),('Accountant','allow-update-paymentitem'),('Cashier','allow-update-paymentitem'),('Cashier Manager','allow-update-paymentitem'),('CRO','allow-update-paymentitem'),('Accountant','allow-view-op'),('Cashier','allow-view-op'),('Cashier Manager','allow-view-op'),('CRO','allow-view-op'),('super-administrator','Analyst'),('Analyst','basic-role'),('CRO','basic-role'),('lab-manager','basic-role'),('super-administrator','basic-role'),('super-administrator','can-delete-profile'),('super-administrator','Cashier Manager'),('Cashier','create-bill-invoice'),('Cashier Manager','create-bill-invoice'),('Cashier','create-customer-wallet'),('Cashier Manager','create-customer-wallet'),('Cashier','create-on-account'),('Cashier Manager','create-on-account'),('Cashier','create-soa'),('Cashier Manager','create-soa'),('super-administrator','CRO'),('super-administrator','lab-manager'),('Cashier','manage-on-account'),('Cashier Manager','manage-on-account'),('Cashier','manage-soa'),('Cashier Manager','manage-soa'),('super-administrator','profile-full-access'),('rbac-full-access','rbac-assign-permission'),('super-administrator','rbac-full-access'),('Cashier','update-bill-invoice'),('Cashier Manager','update-bill-invoice'),('Cashier','update-on-account'),('Cashier Manager','update-on-account'),('super-administrator','user-full-access'),('super-administrator','view-all-rstl'),('Cashier','view-bill-invoice'),('Cashier Manager','view-bill-invoice'),('Cashier','view-customer-wallet'),('Cashier Manager','view-customer-wallet'),('Cashier','view-on-account'),('Cashier Manager','view-on-account'),('Cashier','view-soa'),('Cashier Manager','view-soa');
/*!40000 ALTER TABLE `tbl_auth_item_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_auth_rule`
--

DROP TABLE IF EXISTS `tbl_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_auth_rule`
--

LOCK TABLES `tbl_auth_rule` WRITE;
/*!40000 ALTER TABLE `tbl_auth_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_backup_config`
--

DROP TABLE IF EXISTS `tbl_backup_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_backup_config` (
  `backup_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `mysqldump_path` varchar(100) NOT NULL,
  `Description` text,
  PRIMARY KEY (`backup_config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_backup_config`
--

LOCK TABLES `tbl_backup_config` WRITE;
/*!40000 ALTER TABLE `tbl_backup_config` DISABLE KEYS */;
INSERT INTO `tbl_backup_config` (`backup_config_id`, `mysqldump_path`, `Description`) VALUES (1,'C:\\Program Files\\MySQL\\MySQL Server 5.7\\bin','MySQLDump path to bin folder');
/*!40000 ALTER TABLE `tbl_backup_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_feedback`
--

DROP TABLE IF EXISTS `tbl_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` tinytext,
  `urlpath_screen` tinytext,
  `details` text,
  `steps` text,
  `reported_by` char(250) DEFAULT NULL,
  `region_reported` char(100) DEFAULT NULL,
  `action_taken` char(250) DEFAULT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `moduletested` char(100) DEFAULT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_feedback`
--

LOCK TABLES `tbl_feedback` WRITE;
/*!40000 ALTER TABLE `tbl_feedback` DISABLE KEYS */;
INSERT INTO `tbl_feedback` (`feedback_id`, `url`, `urlpath_screen`, `details`, `steps`, `reported_by`, `region_reported`, `action_taken`, `date_created`, `moduletested`) VALUES (5,'https://ulimsbackend.onelab.ph/module/extract','2018.8.8.10.5.57.247_ 2ne6mcc35t.png','https://ulimsbackend.onelab.ph/module/extract error on extract','121212','Admin','DOST-IX','none','2018-08-08 10:08:57','reports'),(6,'https://ulimsbackend.onelab.ph/module/extract','2018.8.8.16.51.54.887_ cvt0qdcvwj.png','b','b','Admin','DOST-MIMAROPA','none','2018-08-08 16:52:17','Others');
/*!40000 ALTER TABLE `tbl_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_imagemanager`
--

DROP TABLE IF EXISTS `tbl_imagemanager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_imagemanager` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fileName` varchar(128) NOT NULL,
  `fileHash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `createdBy` int(10) unsigned DEFAULT NULL,
  `modifiedBy` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_imagemanager`
--

LOCK TABLES `tbl_imagemanager` WRITE;
/*!40000 ALTER TABLE `tbl_imagemanager` DISABLE KEYS */;
INSERT INTO `tbl_imagemanager` (`id`, `fileName`, `fileHash`, `created`, `modified`, `createdBy`, `modifiedBy`) VALUES (21,'DOST-XI.jpg','_6l0KmBXSf-N66ifLeIHLsCrv01Jj7jh','2018-01-15 16:41:37','2018-01-15 16:41:37',NULL,NULL),(22,'ab0551ea9fa84e128d4c483a04c86d99479e9408.jpg','fSP0soWS9gn3vcEB987TDc6IHIfClpLl','2018-01-15 16:43:37','2018-01-15 16:43:37',NULL,NULL),(23,'c1f44f4d32ce6b10fcb6ec71f292cfa43323ee6c.jpg','LFfWrKffJEgDqdOpxE0als3_E5_PorzR','2018-01-15 16:44:03','2018-01-15 16:44:03',NULL,NULL),(25,'ab0551ea9fa84e128d4c483a04c86d99479e9408_crop_486x507.jpg','cV16OuH8IjljOXQVx5SHh55zAERPT2nj','2018-01-22 13:30:23','2018-01-22 13:30:23',NULL,NULL),(29,'26971913-1546772542043190-774125253-o.jpg','Jn3RHKW2voCPAI_5HJEeXvBDOdZDI35y','2018-01-22 14:23:02','2018-01-22 14:23:02',NULL,NULL);
/*!40000 ALTER TABLE `tbl_imagemanager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_industry`
--

DROP TABLE IF EXISTS `tbl_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_industry` (
  `industry_id` int(11) NOT NULL AUTO_INCREMENT,
  `classification` varchar(250) CHARACTER SET latin1 NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`industry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_industry`
--

LOCK TABLES `tbl_industry` WRITE;
/*!40000 ALTER TABLE `tbl_industry` DISABLE KEYS */;
INSERT INTO `tbl_industry` (`industry_id`, `classification`, `active`) VALUES (1,'Agriculture, forestry and fishing',1),(2,'Mining and Quarrying',1),(3,'Manufacturing',1),(4,'Electricity, gas, steam and air-conditioning supply',1),(5,'Water supply, sewerage, waste management and remediation activities',1),(6,'Construction',1),(7,'Wholesale and retail trade; repair of motor vehicles and motorcycles',1),(8,'Transportation and Storage',1),(9,'Accommodation and food service activities',1),(10,'Information and Communication',1),(11,'Financial and insurance activities',1),(12,'Real estate activities',1),(13,'Professional, scientific and technical services',1),(14,'Administrative and support service activities',1),(15,'Public administrative and defense; compulsory social security',1),(16,'Education',1),(17,'Human health and social work activities',1),(18,'Arts, entertainment and recreation',1),(19,'Other service activities',1),(20,'Activities of private households as employers and undifferentiated goods and services and producing activities of households for own use',1),(21,'Activities of extraterritorial organizations and bodies',1);
/*!40000 ALTER TABLE `tbl_industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_log_sync`
--

DROP TABLE IF EXISTS `tbl_log_sync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_log_sync` (
  `logsync_id` int(11) NOT NULL AUTO_INCREMENT,
  `tblname` varchar(100) NOT NULL,
  `recordID` int(11) NOT NULL,
  `datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `rstl_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`logsync_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_log_sync`
--

LOCK TABLES `tbl_log_sync` WRITE;
/*!40000 ALTER TABLE `tbl_log_sync` DISABLE KEYS */;
INSERT INTO `tbl_log_sync` (`logsync_id`, `tblname`, `recordID`, `datetime`, `rstl_id`, `user_id`) VALUES (2,'Customer',1778,'2018-08-31 15:05:21',11,1),(3,'Customer',1778,'2018-08-31 15:05:21',11,1),(4,'Customer',1779,'2018-08-31 15:06:12',11,1),(5,'Customer',1779,'2018-08-31 15:06:12',11,1),(6,'Customer',1780,'2018-08-31 15:07:31',11,1);
/*!40000 ALTER TABLE `tbl_log_sync` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_menu`
--

DROP TABLE IF EXISTS `tbl_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `route` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `data` blob,
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`),
  CONSTRAINT `tbl_menu_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `tbl_menu` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_menu`
--

LOCK TABLES `tbl_menu` WRITE;
/*!40000 ALTER TABLE `tbl_menu` DISABLE KEYS */;
INSERT INTO `tbl_menu` (`id`, `name`, `parent`, `route`, `order`, `data`) VALUES (1,'Home',NULL,'/site/index',1,NULL);
/*!40000 ALTER TABLE `tbl_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_message`
--

DROP TABLE IF EXISTS `tbl_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(32) NOT NULL,
  `from` int(11) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text,
  `created_at` datetime NOT NULL,
  `context` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_message`
--

LOCK TABLES `tbl_message` WRITE;
/*!40000 ALTER TABLE `tbl_message` DISABLE KEYS */;
INSERT INTO `tbl_message` (`id`, `hash`, `from`, `to`, `status`, `title`, `message`, `created_at`, `context`) VALUES (1,'413de46eb1c6e970e0018752cc663b91',1,2,1,'Test','Testing emai;l','2018-01-12 11:05:13',''),(2,'c161f92cc41ea66b50f668da2f7cbe19',1,2,1,'Test','fggggfgfgfgf','2018-01-12 11:05:47',''),(3,'1745c19267b5aeddcd062048d7ec4912',2,1,1,'Re: Test','OK admin...thanks','2018-01-12 12:02:31',''),(4,'b1f0d2b59640dbacb0e8b6710a9f2df8',2,1,1,'Re: Test','OK admin...thanks','2018-01-12 12:04:38',''),(5,'f33d46bb69f6104b58d1c926bd017f3a',2,1,1,'Re: Test','OK admin...thanks','2018-01-12 12:05:12',''),(6,'3c086e0f7ebf689f790e84b6031b8ab2',2,1,1,'Re: Test','OK admin...thanks','2018-01-12 12:05:34',''),(7,'68470d890b92b328e34ff6d00186c107',2,1,1,'Re: Test','OK admin...thanks','2018-01-12 12:06:05',''),(8,'76314a7c2850538bc488854861b16493',1,2,1,'Re: Test','','2018-01-12 12:42:32',''),(9,'0d10174be52f4d448873193cde61128e',2,1,-1,'Test Multiple messages','<h1>Testing</h1>\r\nThis is a message...','2018-01-12 14:12:06',''),(10,'6eea46ea65b69bdad5ac83df39b3c7c4',2,1,1,'Test Multiple messages','<h1>Testing</h1>\r\nThis is a message...','2018-01-12 14:13:43',''),(11,'5ab804eca05589b676281bcfb956c640',2,5,0,'Test Multiple messages','<h1>Testing</h1>\r\nThis is a message...','2018-01-12 14:13:49',''),(12,'3be914d9a89936a5e03d37317ba1f68f',1,2,2,'testing email','<p>Hi <strong>Jane,</strong></p>\r\n\r\n<p>please click this link&nbsp;<a href=\"https://web.onelab.ph\">OneLab</a></p>\r\n','2018-01-15 16:57:54',''),(13,'2f13dd38c25ca28b5f588af3fb2610c0',2,1,1,'Re: testing email','<p>OK I will</p>\r\n','2018-01-15 16:59:01','');
/*!40000 ALTER TABLE `tbl_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_message_allowed_contacts`
--

DROP TABLE IF EXISTS `tbl_message_allowed_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_message_allowed_contacts` (
  `user_id` int(11) NOT NULL,
  `is_allowed_to_write` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`is_allowed_to_write`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_message_allowed_contacts`
--

LOCK TABLES `tbl_message_allowed_contacts` WRITE;
/*!40000 ALTER TABLE `tbl_message_allowed_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_message_allowed_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_message_ignorelist`
--

DROP TABLE IF EXISTS `tbl_message_ignorelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_message_ignorelist` (
  `user_id` int(11) NOT NULL,
  `blocks_user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`blocks_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_message_ignorelist`
--

LOCK TABLES `tbl_message_ignorelist` WRITE;
/*!40000 ALTER TABLE `tbl_message_ignorelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_message_ignorelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_migration`
--

DROP TABLE IF EXISTS `tbl_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_migration`
--

LOCK TABLES `tbl_migration` WRITE;
/*!40000 ALTER TABLE `tbl_migration` DISABLE KEYS */;
INSERT INTO `tbl_migration` (`version`, `apply_time`) VALUES ('m000000_000000_base',1515723504),('m161028_084412_init',1515723507),('m161214_134749_create_table_tbl_message_ignorelist',1515723508),('m170116_094811_add_context_field_to_tbl_message_table',1515723510),('m170203_090001_create_table_tbl_message_allowed_contacts',1515723511);
/*!40000 ALTER TABLE `tbl_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_package`
--

DROP TABLE IF EXISTS `tbl_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_package` (
  `PackageID` int(11) NOT NULL AUTO_INCREMENT,
  `PackageName` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`PackageID`),
  UNIQUE KEY `PackageName` (`PackageName`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_package`
--

LOCK TABLES `tbl_package` WRITE;
/*!40000 ALTER TABLE `tbl_package` DISABLE KEYS */;
INSERT INTO `tbl_package` (`PackageID`, `PackageName`, `icon`, `created_at`, `updated_at`) VALUES (1,'lab','laboratory',1515397499,1527658489),(2,'inventory','inventory',1515398542,1515575300),(3,'finance','finance',1522048795,1522897198),(5,'services','services',1523954885,1523955450),(6,'customer','customer',1523954885,1526438257),(7,'reports','reports',1523954885,1523954885),(9,'help','help',1533521746,1533695074),(10,'referral','referral',1536722576,1543211909);
/*!40000 ALTER TABLE `tbl_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_package_details`
--

DROP TABLE IF EXISTS `tbl_package_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_package_details` (
  `Package_DetailID` int(11) NOT NULL AUTO_INCREMENT,
  `PackageID` int(11) NOT NULL,
  `Package_Detail` varchar(100) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`Package_DetailID`),
  UNIQUE KEY `Package_Detail` (`Package_Detail`),
  KEY `PackageID` (`PackageID`),
  CONSTRAINT `tbl_package_details_ibfk_1` FOREIGN KEY (`PackageID`) REFERENCES `tbl_package` (`PackageID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_package_details`
--

LOCK TABLES `tbl_package_details` WRITE;
/*!40000 ALTER TABLE `tbl_package_details` DISABLE KEYS */;
INSERT INTO `tbl_package_details` (`Package_DetailID`, `PackageID`, `Package_Detail`, `url`, `icon`, `created_at`, `updated_at`) VALUES (1,1,'Tester','tester','',1522745698,1531185057),(2,3,'Customer Wallet','/finance/customerwallet','customerwallet',1522896543,1531185398),(4,5,'Test Category','/services/testcategory','testcategory',1524033087,1524033173),(5,5,'Sample Type','/services/sampletype','sampletype',1524195583,1524201517),(6,5,'Test','/services/test','test',1524195672,1531185411),(7,6,'Customers','/customer/info','customerpool',1524195672,1524195672),(8,3,'Order of Payment','/finance/op','orderofpayment',1525834028,1525834028),(9,5,'Workflow Management','/services/workflow','workflow',1525835145,1525835145),(10,1,'Request','/lab/request','labrequest',1526447266,1526447266),(12,5,'Package','/services/packagelist','package',1527648562,1527648562),(13,3,'Accounting Code','/finance/accountingcode','accountingcode',1527842004,1527842004),(14,3,'Financial Reports','/finance/financialreports','financialreports',1527842051,1527842051),(15,3,'Receipt','/finance/cashier/receipt','cashier',1528945142,1533008848),(16,3,'Accounting','/finance/accounting','accounting',1528947012,1528947012),(17,3,'Billing','/finance/billing','billing',1528962664,1528962664),(18,1,'Tagging','/lab/tagging','tagging',1531116148,1531116148),(20,1,'Lab Sample Type','/lab/labsampletype','laboratory',1532667857,1532668711),(21,1,'Sample Types','/lab/sampletype','laboratory',1532668071,1532668700),(22,1,'Sample Type Test Name','/lab/sampletypetestname','laboratory',1532668347,1532668690),(23,1,'Test Name Method','/lab/testnamemethod','laboratory',1532668390,1532668788),(24,1,'Method Reference','/lab/methodreference','laboratory',1532668411,1532668774),(25,1,'Test Name','/lab/testname','laboratory',1532668438,1532668747),(26,1,'Sample','/lab/sample','sampletype',1532936954,1532936954),(27,3,'Deposit','/finance/cashier/deposit','cashier',1533008950,1533008950),(28,3,'OP(Non-Lab)','/finance/accounting/op','cashier',1533009125,1533009125),(29,9,'FAQs','/help/faqs','faq',1533521862,1533695099),(30,9,'Feedback','/help/feedback','feedback',1533626809,1533695114),(32,2,'Products','/inventory/products','inventory',1542354269,1542355991),(33,2,'Entries','/inventory/inventoryentries','inventory',1542358526,1542358526),(34,2,'Withdrawal','/inventory/inventoryentries/withdraw','inventory',1542358608,1542358608);
/*!40000 ALTER TABLE `tbl_package_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_profile`
--

DROP TABLE IF EXISTS `tbl_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `designation` varchar(50) NOT NULL,
  `middleinitial` varchar(50) DEFAULT NULL,
  `rstl_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  `contact_numbers` varchar(100) DEFAULT NULL,
  `image_url` varchar(100) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  `designation_unit` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`profile_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `rstl_id` (`rstl_id`),
  CONSTRAINT `tbl_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`),
  CONSTRAINT `tbl_profile_ibfk_2` FOREIGN KEY (`rstl_id`) REFERENCES `tbl_rstl` (`rstl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_profile`
--

LOCK TABLES `tbl_profile` WRITE;
/*!40000 ALTER TABLE `tbl_profile` DISABLE KEYS */;
INSERT INTO `tbl_profile` (`profile_id`, `user_id`, `lastname`, `firstname`, `fullname`, `designation`, `middleinitial`, `rstl_id`, `lab_id`, `contact_numbers`, `image_url`, `avatar`, `designation_unit`) VALUES (1,1,'Sunico','Nolan',NULL,'System Administrator','Francisco',11,1,'+639058051739','nProfile.png','c1f44f4d32ce6b10fcb6ec71f292cfa43323ee6c.png',NULL),(2,2,'Amparo','Jovita',NULL,'Lab Manager','A',14,1,'09058051739','24058747_1499346930119085_3886918050854750796_n.jpg','ab0551ea9fa84e128d4c483a04c86d99479e9408.jpg',NULL),(3,5,'Sunico','Kyle',NULL,'Student','Cabeltes',4,5,'None','nProfile.png','eaecb6031db12110b3e5223042373dde19165d1d.png',NULL),(4,18,'Tailor','Nolan',NULL,'Programmer','Francisco',11,2,'09058051739',NULL,NULL,NULL),(5,13,'grapa','Janeedi',NULL,'SRS1','A',11,1,'09976639656','map-marker.png','88cd72e20f7c9efd6b1f4db195ddf446d3bf5cfb.png',NULL),(6,20,'Moratalla','Aris',NULL,'SRS II','Despalo',11,1,'','18556978_10155252270936704_5128048672938939244_n.jpg','fe9c9a013795898f4fa79e60d3047667d3eacc24.jpg',NULL),(7,24,'Galleno','Eden',NULL,'nothing','G',11,4,'6783645675',NULL,NULL,NULL),(9,26,'ANALYST','ANALYST',NULL,'analyst','A',11,1,'1234',NULL,NULL,NULL),(10,27,'CASHIER','CASHIER',NULL,'CASHIER','C',11,1,'12345','','','Cashier V'),(11,28,'LABMANAGER','LABMANAGER',NULL,'LABMANAGER','L',11,1,'12345','','',NULL),(12,29,'CRO','CRO',NULL,'CRO','C',16,1,'1234',NULL,NULL,NULL),(13,30,'ANALYST','ANALYST',NULL,'ANALYST','A',16,1,'12345',NULL,NULL,NULL),(14,31,'CASHIER','CASHIER',NULL,'CASHIER','C',16,1,'1234',NULL,NULL,NULL),(15,32,'LABMANAGER2','LABMANAGER2',NULL,'LABMANAGER2','L',16,1,'1234','','',NULL),(16,33,'r9test_accountant','r9test_accountant',NULL,'ACCOUNTANT','',11,1,'','','',NULL),(17,34,'cartest_accountant','cartest_accountant',NULL,'ACCOUNTANT','',16,2,'','','',NULL),(20,39,'Gecosala','Sunny Boy','Sunny Boy T. Gecosala','Adminstrator','Tubil',11,2,NULL,NULL,NULL,NULL),(21,37,'Tubil','Manny',NULL,'Teacher','Test',5,4,'4545454554','WIN_20171113_15_00_12_Pro.jpg','650f18d3a5890cac93d4730facefc4eaa33b3a04.jpg',NULL),(22,38,'Number','Digits',NULL,'Student','Num',13,4,'3434343','Request-1.PNG','662da16df0a05be8d5ba5fa95fd294329e977b2f.PNG',NULL);
/*!40000 ALTER TABLE `tbl_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_quarter`
--

DROP TABLE IF EXISTS `tbl_quarter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_quarter` (
  `quarter_id` int(11) NOT NULL AUTO_INCREMENT,
  `quarter` varchar(11) NOT NULL,
  `period_month` varchar(22) NOT NULL,
  PRIMARY KEY (`quarter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_quarter`
--

LOCK TABLES `tbl_quarter` WRITE;
/*!40000 ALTER TABLE `tbl_quarter` DISABLE KEYS */;
INSERT INTO `tbl_quarter` (`quarter_id`, `quarter`, `period_month`) VALUES (1,'1st Quarter','January - March'),(2,'2nd Quarter','April - June'),(3,'3rd Quarter','July - September'),(4,'4th Quarter','October - December');
/*!40000 ALTER TABLE `tbl_quarter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rstl`
--

DROP TABLE IF EXISTS `tbl_rstl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rstl` (
  `rstl_id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `code` varchar(10) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`rstl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rstl`
--

LOCK TABLES `tbl_rstl` WRITE;
/*!40000 ALTER TABLE `tbl_rstl` DISABLE KEYS */;
INSERT INTO `tbl_rstl` (`rstl_id`, `region_id`, `name`, `code`) VALUES (1,1,'DOST-I','R1'),(2,2,'DOST-II','R2'),(3,3,'DOST-III','R3'),(4,4,'DOST-CALABARZON-L1','R4AL1'),(5,4,'DOST-CALABARZON-L2','R4AL2'),(6,5,'DOST-MIMAROPA','R4B'),(7,6,'DOST-V','R5'),(8,7,'DOST-VI','R6'),(9,8,'DOST-VII','R7'),(10,9,'DOST-VIII','R8'),(11,10,'DOST-IX','R9'),(12,11,'DOST-X','R10'),(13,12,'DOST-XI','R11'),(14,13,'DOST-XII-L1','R12L1'),(15,13,'DOST-XII-L2','R12L2'),(16,15,'DOST-CAR','CAR'),(17,17,'DOST-CARAGA','R13'),(18,16,'DOST-ARMM','ARMM'),(19,19,'DOST-FNRI','FNRI'),(20,20,'DOST-FPRDI','FPRDI'),(21,21,'DOST-ITDI','ITDI'),(22,22,'DOST-MIRDC','MIRDC'),(23,23,'DOST-PTRI','PTRI'),(24,24,'DOST-PNRI','PNRI'),(25,4,'DOST-IVA-L3','R4AL3'),(26,4,'DOST-IVA-L4','R4AL4'),(27,21,'DOST-ADMATEL','ADMATEL'),(101,1,'Food and Drug Administration','FDA'),(102,1,'Department of Health – National Reference Laboratory','NRL'),(103,1,'Fertilizer and Pesticide Authority','FPA'),(104,1,'SGS Philippines','SGS'),(105,1,'F.A.S.T. Laboratories (The First Analytical Services and Technical Cooperative) - Cubao Branch','FAST'),(106,1,'Philippine Institute of Pure and Applied Chemistry','PIPAC'),(107,1,'UP Manila – National Institutes of Health','NIH'),(108,1,'Bureau of Product Standards','BPS'),(109,1,'Philippine Accreditation Bureau\r\n','PAB'),(110,1,'Mines and Geosciences Bureau','MGB'),(111,1,'Sentro sa Pagsusuri, Pagsasanay at Pangangasiwang Pang-Agham at Teknolohiyang Corporation','SENTROTEK'),(112,1,'Optimal Laboratories Inc.','OPTIMAL'),(113,1,'Jefcor Laboratories Inc.','JEFCOR'),(114,1,'Intertek Testing Services, Phils, Inc','INTERTEK'),(115,1,'Qualibet Testing Services Corporation','QUALIBET'),(116,10,'GCH Center For Food Safety and Qaulity, Inc.','GCH'),(117,6,'OSTREA Mineral Laboratories, Inc.','OSTREA');
/*!40000 ALTER TABLE `tbl_rstl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rstl_details`
--

DROP TABLE IF EXISTS `tbl_rstl_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rstl_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rstl_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `contacts` text NOT NULL,
  `shortName` varchar(15) NOT NULL,
  `labName` varchar(255) NOT NULL,
  `labtypeShort` varchar(5) NOT NULL,
  `description` text NOT NULL,
  `website` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rstl_id` (`rstl_id`),
  CONSTRAINT `tbl_rstl_details_ibfk_1` FOREIGN KEY (`rstl_id`) REFERENCES `tbl_rstl` (`rstl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rstl_details`
--

LOCK TABLES `tbl_rstl_details` WRITE;
/*!40000 ALTER TABLE `tbl_rstl_details` DISABLE KEYS */;
INSERT INTO `tbl_rstl_details` (`id`, `rstl_id`, `name`, `address`, `contacts`, `shortName`, `labName`, `labtypeShort`, `description`, `website`) VALUES (1,11,'Department of Science and Technology - IX','Pettit Barracks, Zamboanga City','Contact No. (062) 991-1024, (062) 992-1114','DOST-IX','Regional Standards and Testing Laboratories','RSTL','About RSTL/Description','http://region9.dost.gov.ph/'),(2,8,'Department of Science and Technology Regional Office VI','Magsaysay Village La Paz, Iloilo City','Contact No. (033) 320-0093 loc 108','DOST-VI RSTL','Regional Standards and Testing Laboratory','RSTL','','http://region6.dost.gov.ph/'),(3,6,'DOST - MIMAROPA','PSU Link Rd., Sta. Monica, Puerto Princesa City','Contact No. (048) 433 0489 / 09178844332','DOST - MIMAROPA','Regional Standards and Testing Laboratories','RSTL','','http://region4b.dost.gov.ph/'),(4,7,'Department of Science and Technology V','Regional Center Site, Rawis, Legazpi City','Contact No. (052) 482-0376; (052) 482-1050 loc. 113','DOST-V','Regional Standards and Testing Laboratories','RSTL','','http://region5.dost.gov.ph/'),(5,12,'Department of Science and Technology X','J.V. Seriña Street, Carmen, Cagayan de Oro City','Contact No. (088) 858-3931 local 23/26, (088) 850-2653','DOST-X','Regional Standards and Testing Laboratories','RSTL','','http://region10.dost.gov.ph/'),(6,3,'Department of Science and Technology DOST Regional Office III','Government Center, Maimpis, City of San Fernando, Pampanga','Contact No. (045) 455-0594, (045) 455-0800','DOST-III','Regional Standards and Testing Laboratories','RSTL','','http://region3.dost.gov.ph/'),(7,13,'Department of Science and Technology XI','cor. Friendship-Dumanlas Roads, Bajada, Davao City','Contact No. (082) 221-5428/ 227-1313','DOST XI','Regional Standards and Testing Laboratories','RSTL','','http://region11.dost.gov.ph/'),(8,4,'Department of Science and Technology IVA - CALABARZON','Jamboree Rd. Timugan Los Baños Laguna','Contact No. (049) - 536 - 5013 / (049) - 536 - 4390','DOST - IVA','Regional Standards and Testing Laboratories','RSTL','','http://region4a.dost.gov.ph/'),(9,21,'Department of Science and Technology - Industrial Technology Development Institute','DOST Gen. Santos Ave., Bicutan, Taguig City','Contact No. (02)837-2071 loc. 2188,2189,2198 | Fax No. (02)837-3167','DOST-ITDI','Standards and Testing Division','RDI','','http://www.itdi.dost.gov.ph/'),(10,9,'Department of Science and Technology Regional Office No. 7','Sudlon, Lahug, Cebu City','Contact No. (32) 254-8269 | 414-7477 | 414-7577 | 418-9032 ','DOST 7','Regional Standards and Testing Laboratory','RSTL','','http://ro7.dost.gov.ph/'),(11,10,'Department of Science and Technology VIII','Government Center, Candahug, Palo, Leyte','Contact No. (053) 888-0948, Fax (053) 888-0948','DOST-VIII','Regional Standards and Testing Laboratories','RSTL','','http://region8.dost.gov.ph/'),(12,16,'Department of Science and Technology - Cordillera Administrative Region','BSU Compound, Km6, La Trinidad','Contact No. (074) 422-0979, 422-2214','DOST- CAR','Regional Standards and Testing Laboratory','RSTL','','http://car.dost.gov.ph/'),(13,18,'Autonomous Region in Muslim Mindanao\r\nDEPARTMENT OF SCIENCE AND TECHNOLOGY','ORG Compound, Rosary Heights 7, Cotabato City','Contact No. (064) 421 81 83 / Email Add: dostarmm2014@gmail.com','DOST-ARMM','REGIONAL STANDARDS AND HALAL TESTING LABORATORIES','RSTL','','http://www.armm.dost.gov.ph/'),(14,1,'Department of Science and Technology - I','DMMMSU-MLU Campus, City of San Fernando City, La Union 2500','Contact No. (072)687-17-60, 09461391911, 09950121864','DOST-I','Regional Standards and Testing Laboratories','RSTL','','http://region1.dost.gov.ph/'),(15,2,'Department of Science and Technology - II','n/a','n/a','DOST-II','Regional Standards and Testing Laboratories','RSTL','','http://region2.dost.gov.ph/'),(16,14,'Department of Science and Technology - XII','Regional Government Center, Cotabato City','Contact No. (064) 421-2711 / 6908 Email ad: zphrlaidan@dost.gov.ph','DOST XII','Regional Standards and Testing Laboratories','RSTL','','http://region12.dost.gov.ph/'),(17,17,'Department of Science and Technology - Caraga','Caraga State University Campus, Ampayon, Butuan City','Contact No. (085) 341-0528','DOST-Caraga','Regional Standards and Testing Laboratories','RSTL','','http://caraga.dost.gov.ph/'),(19,19,'Department of Science and Technology - Food and Nutrition Research Institute','Gen. Santos Ave., Bicutan, Taguig City, Metro Manila','(02) 837-2934; (02) 837 2071 to 81 local 2284','DOST-FNRI','Research and Development Institutes','RDI','','http://www.fnri.dost.gov.ph/'),(20,20,'Department of Science and Technology - Forest Products Research and Development Institute','Narra Rd., Forestry Campus, College<br>Los Baños Laguna','(049) 5362586; (049) 5362360; (049) 5362377','DOST-FPRDI','Research and Development Institutes','RDI','','http://www.fprdi.dost.gov.ph/'),(21,22,'Department of Science and Technology - Metals Industry Research and  Development Center','Gen. Santos Ave., Bicutan, Taguig City, Metro Manila','(02) 837-0431 to 38','DOST-MIRDC','Research and Development Institutes','RDI','','http://www.mirdc.dost.gov.ph/'),(22,24,'Department of Science and Technology - Philippine Nuclear Research Institute','Commonwealth Avenue, Diliman, Quezon City','(02) 929-6011','DOST-PNRI','Research and Development Institutes','RDI','','http://www.pnri.dost.gov.ph/'),(23,23,'Department of Science and Technology - Philippine Textile Research Institute','Gen. Santos Ave., Bicutan, Taguig City, Metro Manila','(02) 837-1325; (02) 837-1158; (02) 837-1157','DOST-PTRI','Research and Development Institutes','RDI','','http://www.ptri.dost.gov.ph/'),(24,101,'Food and Drug Administration','n/a','n/a','FDA','Non-DOST','n/a','','http://www.fda.gov.ph/'),(25,102,'National Reference Lab','n/a','n/a','NRL','Non-DOST','n/a','','http://www.nrleamcdoh.org/\r\n'),(26,103,'Fertilizer and Pesticide Authority','n/a','n/a','FPA','Non-DOST','n/a','','http://fpa.da.gov.ph/'),(27,104,'SGS Philippines','n/a','n/a','SGS','Non-DOST','n/a','','http://www.sgs.ph/\r\n'),(28,105,'F.A.S.T. Laboratories (The First Analytical Services and Technical Cooperative)','n/a','n/a','FASTLAB','Non-DOST','n/a','','http://www.fastlaboratories.com.ph/\r\n'),(29,106,'Philippine Institute of Pure and Applied Chemistry','n/a','n/a','PIPAC','Non-DOST','n/a','','http://www.pipac.com.ph/'),(30,107,'UP Manila - National Institutes of Health','n/a','n/a','UP-NIH','Non-DOST','n/a','','http://nih.upm.edu.ph/'),(31,111,'Sentro sa Pagsusuri, Pagsasanay at Pangangasiwang Pang-Agham at Teknolohiyang Corporation','n/a','n/a','SENTROTEK','Non-DOST','n/a','','http://www.sentrotek.com/'),(32,112,'Optimal Laboratories, Inc.','n/a','n/a','OPTIMAL','Non-DOST','n/a','','http://optimallabinc.com/'),(33,113,'Jefcor Laboratories, Inc.','n/a','n/a','JEFCOR','Non-DOST','n/a','','http://jefcorlabs.com/'),(34,114,'Intertek Testing Services Philippines, Inc.','n/a','n/a','INTERTEK','Non-DOST','n/a','','http://www.intertek.com/'),(35,15,'Department of Science and Technology XII-L2','PSTC SARGEN, Brgy, Hall Compound, Calumpang, General Santos City','083-554-7997','DOST XII-L2','Regional Standards and Testing Laboratories','RSTL','','http://region12.dost.gov.ph/'),(36,5,'Department of Science and Technology IVA - CALABARZON','Jamboree Rd. Timugan Los Baños Laguna','Contact No. (049)-536-8091','DOST  -IVA','Regional Metrology Lab','RML','','http://region4a.dost.gov.ph/'),(37,25,'Department of Science and Technology - IVA\r\n Provincial Science and Technology Center (Batangas)','Provincial Engineering Compound, Kumintang Llaya, Batangas City, 4200','Contact No. (043)-425-4041','DOST  -IVA','Regional Volumetric Calibration Laboratory','RVCL','','http://region4a.dost.gov.ph/'),(38,26,'Department of Science and Technology - IVA \r\nProvincial Science and Tehnology Center (Cavite)','Provicial Capitol Compd. Luciano, Trece Matires City, Cavite ','Contact No. (046) - 419 -2533 / 419 - 2085','DOST  -IVA','Cavite Water & Wastewater Testing Laboratory','CWWTL','',''),(39,27,'Department of Science and Technology - ADMATEL','n/a','n/a','ADMATEL','DOST','n/a','','');
/*!40000 ALTER TABLE `tbl_rstl_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_status`
--

DROP TABLE IF EXISTS `tbl_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_status`
--

LOCK TABLES `tbl_status` WRITE;
/*!40000 ALTER TABLE `tbl_status` DISABLE KEYS */;
INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (1,'On-going'),(2,'Graduated/ Completed'),(3,'Terminated'),(4,'Withdrawn'),(5,'Non-Compliance'),(6,'Duplicate');
/*!40000 ALTER TABLE `tbl_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_status_sub`
--

DROP TABLE IF EXISTS `tbl_status_sub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_status_sub` (
  `status_sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL,
  `subname` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`status_sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_status_sub`
--

LOCK TABLES `tbl_status_sub` WRITE;
/*!40000 ALTER TABLE `tbl_status_sub` DISABLE KEYS */;
INSERT INTO `tbl_status_sub` (`status_sub_id`, `status_id`, `subname`) VALUES (1,1,'Good Standing'),(2,1,'Suspended'),(3,1,'Leave Of Absence'),(4,1,'No Report'),(5,2,'Graduated'),(6,3,'Terminated'),(7,4,'Withdrawn'),(8,5,'Non-Compliance');
/*!40000 ALTER TABLE `tbl_status_sub` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_terminal`
--

DROP TABLE IF EXISTS `tbl_terminal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_terminal` (
  `terminal_id` int(11) NOT NULL AUTO_INCREMENT,
  `terminal_name` varchar(100) NOT NULL,
  `mac_address` varchar(50) NOT NULL,
  `is_cashier` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`terminal_id`),
  UNIQUE KEY `mac_address` (`mac_address`),
  UNIQUE KEY `terminal_name` (`terminal_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_terminal`
--

LOCK TABLES `tbl_terminal` WRITE;
/*!40000 ALTER TABLE `tbl_terminal` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_terminal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_topics`
--

DROP TABLE IF EXISTS `tbl_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_topics` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `details` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_topics`
--

LOCK TABLES `tbl_topics` WRITE;
/*!40000 ALTER TABLE `tbl_topics` DISABLE KEYS */;
INSERT INTO `tbl_topics` (`topic_id`, `details`) VALUES (1,'How to create Request?'),(2,'How to create Order of Payment?'),(3,'How to create Receipt?'),(4,'How to create Op for non-lab?'),(5,'How to add Deposit?');
/*!40000 ALTER TABLE `tbl_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_topics_details`
--

DROP TABLE IF EXISTS `tbl_topics_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_topics_details` (
  `topics_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `href` varchar(100) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`topics_details_id`),
  KEY `topic_id` (`topic_id`),
  CONSTRAINT `tbl_topics_details_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `tbl_topics` (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_topics_details`
--

LOCK TABLES `tbl_topics_details` WRITE;
/*!40000 ALTER TABLE `tbl_topics_details` DISABLE KEYS */;
INSERT INTO `tbl_topics_details` (`topics_details_id`, `topic_id`, `title`, `href`, `type`) VALUES (1,1,'Step 1','/uploads/faqs/create-request/1.png','png'),(2,1,'Step 2','/uploads/faqs/create-request/2.png','png'),(3,1,'Step 3','/uploads/faqs/create-request/3.png','png'),(4,1,'Step 4','/uploads/faqs/create-request/4.png','png'),(5,1,'Step 5','/uploads/faqs/create-request/5.png','png'),(6,1,'Step 6','/uploads/faqs/create-request/6.png','png'),(7,1,'Step 7','/uploads/faqs/create-request/7.png','png'),(8,1,'Step 8','/uploads/faqs/create-request/8.png','png'),(9,1,'Step 9','/uploads/faqs/create-request/9.png','png'),(10,1,'Step 10','/uploads/faqs/create-request/10.png','png'),(11,1,'Step 11','/uploads/faqs/create-request/11.png','png'),(12,1,'Step 12','/uploads/faqs/create-request/12.png','png'),(13,1,'Step 13','/uploads/faqs/create-request/13.png','png'),(14,2,'Step 1','/uploads/faqs/create-op/1.png','png'),(15,2,'Step 2','/uploads/faqs/create-op/2.png','png'),(16,2,'Step 3','/uploads/faqs/create-op/3.png','png'),(17,2,'Step 4','/uploads/faqs/create-op/4.png','png'),(18,2,'Step 5','/uploads/faqs/create-op/5.png','png'),(19,2,'Step 6','/uploads/faqs/create-op/6.png','png'),(20,2,'Step 7','/uploads/faqs/create-op/7.png','png'),(21,2,'Step 8','/uploads/faqs/create-op/8.png','png'),(22,2,'Step 9','/uploads/faqs/create-op/9.png','png'),(23,2,'Step 10','/uploads/faqs/create-op/10.png','png'),(24,2,'Step 11','/uploads/faqs/create-op/11.png','png'),(25,2,'Step 12','/uploads/faqs/create-op/12.png','png'),(26,2,'Step 13','/uploads/faqs/create-op/13.png','png'),(27,2,'Step 14','/uploads/faqs/create-op/14.png','png'),(28,3,'Step 1','/uploads/faqs/create-receipt/1.png','png'),(29,3,'Step 2','/uploads/faqs/create-receipt/2.png','png'),(30,3,'Step 3','/uploads/faqs/create-receipt/3.png','png'),(31,3,'Step 4','/uploads/faqs/create-receipt/4.png','png'),(32,3,'Step 5','/uploads/faqs/create-receipt/5.png','png'),(33,3,'Step 6','/uploads/faqs/create-receipt/6.png','png'),(34,3,'Step 7','/uploads/faqs/create-receipt/7.png','png'),(35,3,'Step 8','/uploads/faqs/create-receipt/8.png','png'),(36,3,'Step 9','/uploads/faqs/create-receipt/9.png','png'),(37,3,'Step 10','/uploads/faqs/create-receipt/10.png','png'),(38,3,'Step 11','/uploads/faqs/create-receipt/11.png','png'),(39,3,'Step 12','/uploads/faqs/create-receipt/12.png','png'),(40,4,'Step 1','/uploads/faqs/non-lab/1.png','png'),(41,4,'Step 2','/uploads/faqs/non-lab/2.png','png'),(42,4,'Step 3','/uploads/faqs/non-lab/3.png','png'),(43,4,'Step 4','/uploads/faqs/non-lab/4.png','png'),(44,4,'Step 5','/uploads/faqs/non-lab/5.png','png'),(45,4,'Step 6','/uploads/faqs/non-lab/6.png','png'),(46,4,'Step 7','/uploads/faqs/non-lab/7.png','png'),(47,4,'Step 8','/uploads/faqs/non-lab/8.png','png'),(48,4,'Step 9','/uploads/faqs/non-lab/9.png','png'),(49,4,'Step 10','/uploads/faqs/non-lab/10.png','png'),(50,4,'Step 11','/uploads/faqs/non-lab/11.png','png'),(51,5,'Step 1','/uploads/faqs/create-receipt/13.png',NULL),(52,5,'Step 2','/uploads/faqs/create-receipt/14.png',NULL),(53,5,'Step 3','/uploads/faqs/create-receipt/15.png',NULL),(54,5,'Step 4','/uploads/faqs/create-receipt/16.png',NULL),(55,5,'Step 5','/uploads/faqs/create-receipt/17.png',NULL),(56,5,'Step 6','/uploads/faqs/create-receipt/18.png',NULL),(57,5,'Step 7','/uploads/faqs/create-receipt/19.png',NULL);
/*!40000 ALTER TABLE `tbl_topics_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_upload_package`
--

DROP TABLE IF EXISTS `tbl_upload_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_upload_package` (
  `upload_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(100) DEFAULT NULL,
  `module_name` varchar(100) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`upload_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_upload_package`
--

LOCK TABLES `tbl_upload_package` WRITE;
/*!40000 ALTER TABLE `tbl_upload_package` DISABLE KEYS */;
INSERT INTO `tbl_upload_package` (`upload_id`, `package_name`, `module_name`, `created_at`, `updated_at`) VALUES (1,'lab.zip','Lab.zip',1515397495,1515397495);
/*!40000 ALTER TABLE `tbl_upload_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` (`user_id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES (1,'Admin','H06d598TowxCUB1bRLqPHNsPMtkp3MCK','$2y$13$FZqPeW2UZnylgrGIQyToGekR9YhIMlpif2IAOZaLr7qm.ffJAqA02','4CnX1D1IKs70gFic28bClG-vbQfzldAB_1517198782','nolansunico@gmail.com',10,1512923120,1517198782),(2,'Jane','hbCjwM0lqOoBGNjCwnh1DET0eplo_LtA','$2y$13$D5GOVlWowO9I2jmIvbL/xuNgGLPIhDRoNJbZPkEaCr2PRW/LuHsmK',NULL,'janesunico2015@gmail.com',10,1513845779,1543366671),(5,'Kyle','7QcI5fZmXdkOsCy711C-wS1GlUjIfA7t','$2y$13$ImnGqbmO/1AMHDna6nAw8OUQgvzjRHRA1HWiu2THmO8FEtaVS/9Eu',NULL,'kylesunico@gmail.com',10,1513846447,1513907171),(13,'Janeedi','9zd8cSZUlbzKQCput-BQCk2anM0_aVrT','$2y$13$p05tmqpnvPvNZJVwJcEnN.Dkxk9vlvp0hs2TFYu4bTFSEwXp8mNKe',NULL,'grapajaneedi@gmail.com',10,1516093201,1521097835),(18,'Nolan','Ay4LPzV1vSFoB_2JeCy7XB4zGgqXGdVR','$2y$13$AyeXtRl68mOmu8ZpQ0luB.MsT0BAK380ZGr0LzhZeHq65ml/5uIlm',NULL,'nolan2@tailormadetraffic.com',10,1517984507,1517984550),(19,'papa','H06d598TowxCUB1bRLqPHNsPMtkp3MCK','$2y$13$NeDyUf/cBOv8/gz/Q9XLA.ayrFPoAylkYfzbq3ebCu8w/C2rnI0SW',NULL,'nolan@tailormadetraffic.com',10,1519972939,1526877840),(20,'arismoratalla','_PvjCh_g2z7ChpPPNmN7icnqKGIbKXXw','$2y$13$a7vuETmr01yfTqMvJOPeuucZ8gj3fcSGREVqL076IlnO8wm6PDY86',NULL,'arismoratalla@gmail.com',10,1532315374,1532315604),(23,'Berujiru','0egAk6yWDixmw8K3qTxXb3vBRMmIOE3q','$2y$13$DMG99xBP6vD9PJj0cYn3EO4W/JC0l8jjWLnX9wclePkHHHLGpRSaS',NULL,'b.cutara@gmail.com',10,1532321973,1532322048),(24,'eggalleno','FdK6673eYSRBeY9JneJxG9XVZEsTk1hv','$2y$13$6RUUS1SsL3LQp9Qp..TmSe1T14r680Qw94J3jv6nwrErOT5VE5Nse',NULL,'gallenoeden09@gmail.com',10,1532322774,1532322862),(25,'r9test_cro','ojsBBt7H-lbbspvI6BBu0vK6k14WCHhg','$2y$13$7YH/fHmpgnKvJKZzvtiXIOlyLCooiEHGb57S/gBlaShHAQuTubov6',NULL,'r9test_cro@gmail.com',10,1532584004,1532650751),(26,'r9test_analyst','j29NW5F5tGIwDiCammXC2Lqc8Dq9MxkV','$2y$13$YKgq/qqNBy9kv.uNIXSng.g.IUEYxmcfd8.HrrCW6vmuSweNcy1Qa',NULL,'r9test_analyst@gmail.com ',10,1532584111,1532650787),(27,'r9test_cashier','jPjsMhnz0j9pkSLMnnSh11lqn97MIjlW','$2y$13$tr7C/UFPLP1LaOM0myljaeknDi/Foyszff2H2h1W3em6XQw5ndD5K',NULL,'r9test_cashier@gmail.com ',10,1532584167,1532650808),(28,'r9test_labmanger','ag3lwbfsFBjF1jcfqPVAVHod-Siz_vQ-','$2y$13$msbYdg2PmIpgX.Az3/FwSOcC4aGcR/9xlsdzJMcAJj8naF6ElQWMS',NULL,'r9test_labmanager@gmail.com',10,1532584279,1532668293),(29,'cartest_cro','1CkABq37q-QxqefGeAiDYgAqeX3qCIB3','$2y$13$vxrlTbxscEBOF94SjzZ04eT4a9dhtx9JajVO16AZSXvv0Fp7txaEG',NULL,'cartest_cro@gmail.com',10,1532650979,1532651911),(30,'cartest_analyst','KW21eqOG4pp7dX3x4XL3eLVCTBGXcfGy','$2y$13$FOwh/qAmcxQ7bIioifv/NO5D0IZ83IjmZi8KkC3Je5M1SkklnbeNu',NULL,'cartest_analyst@gmail.com',10,1532651041,1532651733),(31,'cartest_cashier','H8uTJ2Px5HtT0PhAP-hVlbsyX3tq7zmf','$2y$13$itMI9hhXxfVD7C.bmBMJbeHGo5RrLiVCzRtKOYvec1JnNXkEpWI4.',NULL,'cartest_cashier@gmail.com',10,1532651645,1532651740),(32,'cartest_labmanager','jji8OQpnb1yQOrYbfUjo5NKqJEaePIXE','$2y$13$1B61je0tqzBAGwfSW18daugpkZPc1mANoMFbSbg..iFc.8orbhvg6',NULL,'cartest_labmanager@gmail.com',10,1532651713,1532651751),(33,'r9test_accountant','gRAOWOBswS0igsdsz8N_okP87vx3tT2e','$2y$13$XUjQtEPVV5dibE1I89oOn.fyEvv.JFgaIQzCBQRdMVi1wKqaWeqeO',NULL,'r9test_accountant@gmail.com',10,1533100291,1533100299),(34,'cartest_accountant','fgEJwhs333GxG2N2x1HmwAZjfwT-6rtt','$2y$13$OGiX/vTjOVWdOOAyn.QpheHzuSjHki9jro1BLG2ovYviC/1NQvuB.',NULL,'cartest_accountant@gmail.com',10,1533100531,1533100536),(37,'Wala','44U4xXaotrW7RV5iTUAHLBR83LhrMtgH','$2y$13$S6Ntm/b05/Fez3yP0qkMueCcuT47GMHU4IZn4KgvCRR2sGk82ouo2',NULL,'wala@gmail.com',0,1542762832,1542762832),(38,'1234','J0Cie06m25W68tpSPtxKQJqSOcP9V_n-','$2y$13$xndcy473aTE0EQ3Sf/Uqn.r3Lj8hzG9sS4KGxuEZJt0sNcYvjyHi6',NULL,'123@gmail.com',0,1542764019,1542764019),(39,'stg','rLu4JMCwWFZh2jBIwz65W5CDi8OHLsdE','$2y$13$swXfJw0I4VV0xZd30v6Jue.nEKLhBnMpx/SC.2zT5lFJFMs/mEsRe',NULL,'sbgecosala@gmail.com',10,1543215988,1543215998);
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vw_getuser`
--

DROP TABLE IF EXISTS `vw_getuser`;
/*!50001 DROP VIEW IF EXISTS `vw_getuser`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_getuser` AS SELECT 
 1 AS `user_id`,
 1 AS `username`,
 1 AS `auth_key`,
 1 AS `password_hash`,
 1 AS `password_reset_token`,
 1 AS `email`,
 1 AS `status`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `lastname`,
 1 AS `firstname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_labrbac`
--

DROP TABLE IF EXISTS `vw_labrbac`;
/*!50001 DROP VIEW IF EXISTS `vw_labrbac`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_labrbac` AS SELECT 
 1 AS `lab_manager_id`,
 1 AS `user_id`,
 1 AS `labmanager`,
 1 AS `lab_id`,
 1 AS `labname`,
 1 AS `updated_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_getuser`
--

/*!50001 DROP VIEW IF EXISTS `vw_getuser`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_getuser` AS (select `tbl_user`.`user_id` AS `user_id`,`tbl_user`.`username` AS `username`,`tbl_user`.`auth_key` AS `auth_key`,`tbl_user`.`password_hash` AS `password_hash`,`tbl_user`.`password_reset_token` AS `password_reset_token`,`tbl_user`.`email` AS `email`,`tbl_user`.`status` AS `status`,`tbl_user`.`created_at` AS `created_at`,`tbl_user`.`updated_at` AS `updated_at`,`tbl_profile`.`lastname` AS `lastname`,`tbl_profile`.`firstname` AS `firstname` from (`tbl_user` join `tbl_profile` on((`tbl_profile`.`user_id` = `tbl_user`.`user_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_labrbac`
--

/*!50001 DROP VIEW IF EXISTS `vw_labrbac`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_labrbac` AS (select `eulims_lab`.`tbl_lab_manager`.`lab_manager_id` AS `lab_manager_id`,`eulims`.`tbl_profile`.`user_id` AS `user_id`,concat(`fnProperCase`(`eulims`.`tbl_profile`.`firstname`),' ',left(upper(`eulims`.`tbl_profile`.`middleinitial`),1),'. ',`fnProperCase`(`eulims`.`tbl_profile`.`lastname`)) AS `labmanager`,`eulims_lab`.`tbl_lab_manager`.`lab_id` AS `lab_id`,`eulims_lab`.`tbl_lab`.`labname` AS `labname`,`eulims_lab`.`tbl_lab_manager`.`updated_at` AS `updated_at` from (((`eulims`.`tbl_profile` join `eulims`.`tbl_auth_assignment` on((`eulims`.`tbl_auth_assignment`.`user_id` = `eulims`.`tbl_profile`.`user_id`))) left join `eulims_lab`.`tbl_lab_manager` on((`eulims_lab`.`tbl_lab_manager`.`user_id` = `eulims`.`tbl_profile`.`user_id`))) left join `eulims_lab`.`tbl_lab` on((`eulims_lab`.`tbl_lab`.`lab_id` = `eulims_lab`.`tbl_lab_manager`.`lab_id`))) where (`eulims`.`tbl_auth_assignment`.`item_name` = 'lab-manager')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-06 15:29:55
