<?php

/*
 * Project Name: eulims * 
 * Copyright(C)2018 Department of Science & Technology -IX * 
 * Developer: Eng'r Nolan F. Sunico  * 
 * 01 10, 18 , 8:43:01 AM * 
 * Module: myClass * 
 */

namespace frontend\modules\tagging\components;

/**
 * Description of myClass
 *
 * @author OneLab
 */
interface ICLass{
    public function SetName($name);
    public function SetAddress($add);
}