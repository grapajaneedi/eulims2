<?php



use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\bootstrap\Modal;
use kartik\select2\Select2;
use common\models\lab\Customer;
use yii\helpers\ArrayHelper;


/* @var $this yii\web\View */
/* @var $searchModel common\models\finance\CustomerwalletSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Customer Wallets';
$this->params['breadcrumbs'][] = $this->title;
$this->registerJsFile("/js/finance/finance.js");
?>

<div class="customerwallet-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Customerwallet', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
             // 'customerwallet_id',
            [
                'attribute'=>'customer_id',
                'value'=>'customer.customer_name',
                'filter'=>Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'customer_id',
                    'data' => ArrayHelper::map(Customer::find()->all(), 'customer_id', 'customer_name'),
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'hideSearch' => false,
                    'options' => [
                        'placeholder' => 'Select a Customer',
                    ]
                ]),
            ],
            'date',
            'last_update',
            'balance',
             // ['class' => 'yii\grid\ActionColumn'],
            ['class' => 'yii\grid\ActionColumn',
                'contentOptions' => ['style' => 'width: 8.7%'],
                'visible'=> Yii::$app->user->isGuest ? false : true,
                'template' => '{add}{view}',
                'buttons'=>[
                    'add'=>function ($url, $model) {
                        $t = '/finance/customertransaction/create?customerwallet_id='.$model->customerwallet_id;
                        return Html::button('<span class="glyphicon glyphicon-plus"></span>', ['value'=>Url::to($t), 'class' => 'btn btn-primary custom_button','title' => Yii::t('app', 'Add Funds')]);
                    },
                    'view'=>function ($url, $model) {
                        $t = '/finance/customerwallet/view?id='.$model->customerwallet_id;
                        return Html::button('<span class="fa fa-eye"></span>', ['value'=>Url::to($t), 'class' => 'btn btn-primary custom_button','title' => Yii::t('app', 'View History')]);
                    },
                    
                ],
            ],

        ],
    ]); 



    ?>
</div>


