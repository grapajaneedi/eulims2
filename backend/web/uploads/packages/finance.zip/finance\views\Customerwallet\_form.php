<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use common\models\lab\Customer;
use kartik\select2\Select2;


/* @var $this yii\web\View */
/* @var $model common\models\finance\Customerwallet */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="customerwallet-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'balance')->textInput(['maxlength' => true]) ?>

  

    <?php 
	// Normal select with ActiveForm & model
	echo $form->field($model, 'customer_id')->widget(Select2::classname(), [
    	'data' => ArrayHelper::map(Customer::find()->all(), 'customer_id', 'customer_name'),
    	'language' => 'en',
    	'options' => ['placeholder' => 'Select a customer ...'],
    	'pluginOptions' => [
      	  'allowClear' => true
    	],
	]);

    ?>
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
