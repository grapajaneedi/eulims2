<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\finance\Customerwallet */

$this->title = $model->customerwallet_id;
$this->params['breadcrumbs'][] = ['label' => 'Customerwallets', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="customerwallet-view">

    <!-- <h1><?= Html::encode($this->title) ?></h1> -->

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->customerwallet_id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->customerwallet_id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            // 'customerwallet_id',
            'date',
            'last_update',
            'balance',
            'customer.customer_name',
        ],
    ]) ?>



    <pre>
        <?= print_r($transactions);?>
    </pre>

</div>
